/**
 * WhatsCore.AI - Maverick Edition
 *
 * Mesaj Controller (Controller) - v5.0.1 (SyntaxError & Stability Patch)
 * YENİLİK: Media və mətn buferlərinin toqquşması problemi tam həll edilib.
 * Bütün funksiyalar (Lead, Reply, Typing, Multi-Media) tam inteqrasiya olunub.
 */
const { getAIResponse } = require("../services/ai");
const mediaProcessor = require("../services/mediaProcessor");
const { logWithTimestamp } = require("../utils/logger");
const fs = require("fs-extra");
const { saveHistory } = require("../services/historyManager");
const { findOrCreateLead } = require("../services/leadManager");

const textBuffer = {};
const mediaBuffer = {};
const TEXT_BUFFER_TIMEOUT = (process.env.BUFFER_TIMEOUT_SECONDS || 8) * 1000;
const MEDIA_BUFFER_TIMEOUT = 3000;

async function replyToMessage(client, chatId, responseText, originalMessage) {
    try {
        if (!responseText || responseText.trim() === "") return;
        const options = { quotedMessageId: originalMessage ? originalMessage.id._serialized : null };
        const sentMessage = await client.sendMessage(chatId, responseText.trim(), options);
        logWithTimestamp(`✅ Cavab (Reply) uğurla göndərildi: [${chatId}]`);
        await saveHistory(chatId, { type: "text", content: responseText.trim(), sender: "assistant", quotedMsgId: originalMessage ? originalMessage.id._serialized : null }, sentMessage.id._serialized);
    } catch (error) {
        logWithTimestamp(`❌ Cavab göndərmə xətası [${chatId}]:`, error.message);
    }
}

async function flushTextBuffer(client, chatId) {
    if (!textBuffer[chatId] || textBuffer[chatId].messages.length === 0) return;
    const bufferCopy = { ...textBuffer[chatId] };
    delete textBuffer[chatId];
    const lastMessage = bufferCopy.originalMessages[bufferCopy.originalMessages.length - 1];
    const combinedText = bufferCopy.messages.join("\n");
    logWithTimestamp(`⏳ Mətn Buferi boşaldılır [${chatId}]: "${combinedText}"`);
    try {
        const minThinkingTime = 1500;
        const aiPromise = getAIResponse(chatId, { text: combinedText, media: [] });
        const [aiResponse] = await Promise.all([aiPromise, new Promise(resolve => setTimeout(resolve, minThinkingTime))]);
        await replyToMessage(client, chatId, aiResponse, lastMessage);
    } catch (error) {
        logWithTimestamp(`❌ Mətn buferindən AI cavabı alma xətası:`, error);
    }
}

async function flushMediaBuffer(client, chatId) {
    if (!mediaBuffer[chatId] || mediaBuffer[chatId].messages.length === 0) return;
    const bufferCopy = { ...mediaBuffer[chatId] };
    delete mediaBuffer[chatId];
    const lastMessage = bufferCopy.messages[bufferCopy.messages.length - 1];
    logWithTimestamp(`⏳ Media Buferi boşaldılır [${chatId}]: ${bufferCopy.messages.length} media faylı tapıldı.`);
    const temporaryFiles = [];
    const chat = await lastMessage.getChat();
    try {
        chat.sendStateTyping();
        let combinedCaption = bufferCopy.messages.map(msg => msg.body || "").filter(Boolean).join("\n");
        let mediaInputs = [];
        for (const msg of bufferCopy.messages) {
            const mediaPath = await mediaProcessor.saveMedia(msg);
            temporaryFiles.push(mediaPath);
            mediaInputs.push({ path: mediaPath, mimeType: msg.mimetype });
        }
        const CHUNK_SIZE = 5;
        for (let i = 0; i < mediaInputs.length; i += CHUNK_SIZE) {
            const chunk = mediaInputs.slice(i, i + CHUNK_SIZE);
            const userInput = {
                text: i === 0 ? combinedCaption : `(Davamı) Paket ${Math.floor(i / CHUNK_SIZE) + 1}`,
                media: chunk
            };
            logWithTimestamp(`🧠 AI-yə ${chunk.length} media ilə sorğu göndərilir...`);
            const minThinkingTime = 2000;
            const aiPromise = getAIResponse(chatId, userInput);
            const [aiResponse] = await Promise.all([aiPromise, new Promise(resolve => setTimeout(resolve, minThinkingTime))]);
            await replyToMessage(client, chatId, aiResponse, lastMessage);
        }
    } catch (error) {
        logWithTimestamp(`❌ Media buferini emal edərkən xəta:`, error);
    } finally {
        chat.clearState();
        await Promise.all(temporaryFiles.map(fp => fs.unlink(fp).catch(e => logWithTimestamp(`❌ Müvəqqəti media faylı silinmədi: ${fp}`, e.message))));
    }
}

async function handleMessage(client, message) {
    const chatId = message.from;
    if (message.fromMe || message.isStatus) return;
    
    try {
        const chat = await message.getChat();
        await chat.sendSeen();
        const lead = await findOrCreateLead(chatId);
        logWithTimestamp(`📨 Mesaj [${lead.status}] statuslu lead üçün emal edilir: [${lead.lead_id}]`);
        const quotedMsgId = (message.hasQuotedMsg && message._data.quotedMsg) ? message._data.quotedMsg.id._serialized : null;
        await saveHistory(chatId, { type: message.type, content: message.body || "", sender: "user", quotedMsgId }, message.id._serialized);

        if (message.hasMedia) {
            if (textBuffer[chatId]?.timer) {
                clearTimeout(textBuffer[chatId].timer);
                await flushTextBuffer(client, chatId);
            }
            if (mediaBuffer[chatId]?.timer) clearTimeout(mediaBuffer[chatId].timer);
            if (!mediaBuffer[chatId]) mediaBuffer[chatId] = { messages: [] };
            mediaBuffer[chatId].messages.push(message);
            logWithTimestamp(`📥 Media buferə əlavə olundu: [${chatId}]. Hazırda ${mediaBuffer[chatId].messages.length} fayl var.`);
            mediaBuffer[chatId].timer = setTimeout(() => flushMediaBuffer(client, chatId), MEDIA_BUFFER_TIMEOUT);
        } else if (message.type === "chat" && message.body.trim() !== "") {
            if (mediaBuffer[chatId]?.timer) {
                clearTimeout(mediaBuffer[chatId].timer);
                await flushMediaBuffer(client, chatId);
            }
            chat.sendStateTyping();
            if (textBuffer[chatId]?.timer) clearTimeout(textBuffer[chatId].timer);
            if (!textBuffer[chatId]) textBuffer[chatId] = { messages: [], originalMessages: [] };
            textBuffer[chatId].messages.push(message.body);
            textBuffer[chatId].originalMessages.push(message);
            textBuffer[chatId].timer = setTimeout(() => flushTextBuffer(client, chatId).finally(() => chat.clearState()), TEXT_BUFFER_TIMEOUT);
        } else {
            // Bufersiz, tək mesajlar (location və s.)
            chat.sendStateTyping();
            let userInput = { text: message.body || "", media: [] };
            if (message.type === "location") {
                userInput.text = `İstifadəçi bir məkan göndərdi: Lat: ${message.location.latitude}, Lon: ${message.location.longitude}.`;
            }
            const aiResponse = await getAIResponse(chatId, userInput);
            await replyToMessage(client, chatId, aiResponse, message);
            chat.clearState();
        }
    } catch (error) {
        logWithTimestamp(`❌ Mesaj emalında ümumi xəta [${chatId}]:`, error);
        await replyToMessage(client, chatId, "🤖 Üzr istəyirəm, naməlum bir xəta baş verdi.", message);
    }
}

module.exports = { handleMessage };
