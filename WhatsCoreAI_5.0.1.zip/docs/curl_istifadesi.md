# Whatscore.AI API Istifadə Qaydası v3.4.0

Bu sənəd `Whatscore.AI` sisteminə **media**, **lokasiya**, **məhsul**, **buton**, **sənəd**, **əlaqə**, **audio**, **video** və digər WhatsApp mesajlarını **cURL vasitəsilə göndərmək üçün təlimat** verir.

---

## 📍 Lokasiya Mesajı Göndər

**POST:**

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "location",
  "from": "994702353552@c.us",
  "originalContent": {
    "latitude": 40.4093,
    "longitude": 49.8671,
    "name": "PierringShot Gənclik",
    "address": "ADU yaxınlığı"
  }
}'
```

**GET:**

```bash
curl "http://localhost:9876/api/process?type=location&from=994702353552@c.us&originalContent=%7B%22latitude%22%3A40.4093%2C%22longitude%22%3A49.8671%2C%22name%22%3A%22PierringShot%20G%C9%99nclik%22%2C%22address%22%3A%22ADU%20yax%C4%B1nl%C4%B1%C4%9F%C4%B1%22%7D"
```

---

## 📷 Şəkil Göndər

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "image",
  "from": "994702353552@c.us",
  "originalContent": {
    "path": "media/image/test.jpg",
    "caption": "Yeni məhsul"
  }
}'
```

---

## 🎧 Audio (voice) Göndər

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "audio",
  "from": "994702353552@c.us",
  "originalContent": {
    "path": "media/audio/sample.ogg"
  }
}'
```

---

## 🎥 Video Göndər

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "video",
  "from": "994702353552@c.us",
  "originalContent": {
    "path": "media/video/test.mp4",
    "caption": "Reklam videosu"
  }
}'
```

---

## 📄 Sənəd Göndər

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "document",
  "from": "994702353552@c.us",
  "originalContent": {
    "path": "media/docs/file.pdf",
    "filename": "file.pdf",
    "caption": "Saziş"
  }
}'
```

---

## 👤 Kontakt Göndər

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "contact",
  "from": "994702353552@c.us",
  "originalContent": {
    "name": "Elşən Usta",
    "phone": "+994502001122"
  }
}'
```

---

## 🛍️ Məhsul Göndər

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "product",
  "from": "994702353552@c.us",
  "originalContent": {
    "name": "Macbook Pro",
    "price": 3450
  }
}'
```

---

## 🔘 Buton Göndər

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "buttons",
  "from": "994702353552@c.us",
  "originalContent": {
    "text": "Xahiş edirik seçim edin:",
    "buttons": ["Qiymət sorş", "Servisə gəl"],
    "title": "PierringShot Electronics",
    "footer": "Sizin xətti..."
  }
}'
```

---

## 🧠 Chat (AI)

```bash
curl -X POST http://localhost:9876/api/process \
-H "Content-Type: application/json" \
-d '{
  "type": "chat",
  "from": "994702353552@c.us",
  "content": "Qulaqlıq nə vaxt gələcək?"
}'
```

---

## ✅ Qeyd:

* **Bütün POST requestlərdə** `type`, `from`, `content?`, `originalContent` obyektləri olmalıdır.
* **`originalContent`** obyektin dəqiq strukturu mesaj tipinə görə fərqlidir.
* `user_contexts/` qovluğu istər chat, istər curl istəyi olsun — **hər biri avtomatik yazılır**.
* Şəkil/audio faylları local `media/` qovluğunda saxlanmalıdır.

---
