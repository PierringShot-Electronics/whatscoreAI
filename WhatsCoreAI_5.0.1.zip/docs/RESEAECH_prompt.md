[+] PIERRINGSHOT WWEBJS SİSTEMİ İŞƏ SALINIR...  
[1/6] Köhnə məlumatlar təmizlənir...  
[2/6] Lazımlı qovluqlar yaradılır...  
[3/6] Köhnə proseslər dayandırılır...                                  Bridge prosesi tapılmadı  
Listener prosesi tapılmadı  
Port 9876 boş idi  
[4/6] Port yoxlaması...  
[5/6] Python bridge servisi başladılır...                              [6/6] Node.js listener servisi başladılır...  
  
[✓] SİSTEM UĞURLA İŞƏ SALINDI!  
----------------------------------------                               Bridge Status:  
active  
----------------------------------------  
İstifadə qaydası:  
1. Terminalda görünən QR kodu WhatsApp-da skan edin  
2. Bridge logları: tail -f core/logs/bridge.log  
3. Listener logları: tail -f core/logs/listener.log                    ----------------------------------------  
PierringShot Electronics™ - Rəsmi AI Assistant  
  
# pierring @ fedora in ~/whatscore.ai [14:01:38]

ƏN ALTDA SƏNƏ VERİLƏN TAPŞIRIGA DİQQƏT ET! Həmçinin məncə yuxarıda verdiyim dipsikin cavabı hərbi şey açıqlaya biləcək qədər yetərlidir hətta buyur aşağıdadırsa o deepseek verdiyim bu promta vermiş olduğu cavabdır təşəkkürlər gözləyirəm başlar ver skriptlerimi🥰!!!

İlk gonderdiyim mesaj DEEPSEEKin ona verilən bu tapşırıq üçün vermiş olduğu cavab idi

PierringShot Electronics™ Multimodal AI Sisteminin Təkmilləşdirilməsi  
  
İcmal və Mövcud Sistem Arxitekturası  
  
PierringShot Electronics™ şirkətinin hazırda istifadədə olan multimodal AI backend sistemi bir neçə əsas moduldan ibarətdir. Bu sistem WhatsApp üzərindən göndərilən mesajları (mətn və fərqli media növləri) emal edir və Azərbaycan dilində cavablar qaytarır. Aşağıda mövcud komponentlər və onların funksiyaları verilmişdir:  
  
groq_modules.py – Groq API vasitəsilə multimodal emal aparır. Bu modul göndərilən medianın tipinə əsasən uyğun modeli işə salır: şəkillər üçün təsvir generasiyası (caption) və optik mətn tanıma (OCR), audio fayllar üçün nitqin mətnə çevrilməsi (transkript), video fayllar üçün səs transkripti və video kadrlardan təsvir çıxarılması. Bu modul Groq buludunda yerləşən LLM və ya xüsusi modellərə sorğular göndərir.  
  
bridge.py – Flask-əsaslı bir API serveridir. Bu server WhatsApp WebJS inteqrasiyasından (wwebjs_listener.js modulundan) gələn sorğuları qəbul edir, mesajın tipinə uyğun emal axınını müəyyənləşdirir və müvafiq groq_modules.py funksiyalarını çağırır. Emal edilmiş nəticəni JSON formatında cavab kimi qaytarır.  
  
wwebjs_listener.js – Node.js mühitində işləyən WhatsApp WebJS inteqrasiya moduludur. Bu modul WhatsApp Web vasitəsilə gələn mesajları (mətn, şəkil, audio, video, lokasiya və s.) dinləyir. Hər yeni mesajı aldıqda, əgər media faylı varsa onu müvəqqəti yaddaşa yazır və sonra bridge.py API-nə HTTP sorğu göndərir. Məsələn, şəkil mesajı gələndə fayl yüklənir və bridge.py-yə POST /process_image sorğusu ilə göndərilir.  
  
csv_search.py / e_commerce.py – Məhsul məlumat bazası modulları. Bu modul(lar) məhsulların axtarışı, sifariş yaradılması, qiymət və stok sorğularının cavablandırılmasından məsuldur. Hal-hazırda iki seçim dəstəklənir: ya sadə CSV faylında məhsul siyahısı üzərindən axtarış, ya da Memento Database (lokal DB) vasitəsilə axtarış. Sorğudan asılı olaraq get_product(product_name), get_product_price(product_id), get_product_stock(product_id) və create_order(product_id, user_info, ...) kimi funksiyalar mövcuddur.  
  
.env Konfiqurasiya Faylı – Bütün həssas konfiqurasiya parametrləri və açarlar burada JSON formatında saxlanılır. Buraya Groq API açarları, model identifikatorları, yol parametrləri, xidmət URL-ləri və s. daxildir. Sistem işə düşərkən dotenv kitabxanası ilə bu açarlar yüklənir.  
  
user_contexts/ Qovluğu – Bu qovluqda hər bir istifadəçinin chat tarixçəsi JSON formatında ardıcıllıqla saxlanılır. Hər dialoq addımı üçün istifadəçinin sorğusu və verilən cavab (o cümlədən media fayllar üçün caption/transkript) burada qeyd edilir. Bu tarixçə növbəti sorğular zamanı konteksti saxlamaq üçün istifadə oluna bilər.  
  
Cari Funksionallıq və Tələblər: Sistem hal-hazırda müxtəlif növ mesajları tanıyıb cavab verə bilir və müəyyən biznes qaydaları mövcuddur:  
  
Dəstəklənən mesaj növləri: chat (mətn), image (şəkil), audio (səs mesajı), video, location (coğrafi lokasiya), product (məhsul kartı), sticker (stiker), vcard (əlaqə kartı), call_log, poll, event və s. Sistem media növünü message.type sahəsindən müəyyən edir və emal axınını seçir.  
  
Cavablar hər zaman Azərbaycan dilində olmalıdır. Üslub texniki, səliqəli və başa düşülən formada qurulur. Yəni istifadəçiyə göndərilən mətndə qrammatik və terminoloji düzgünlük gözlənilir.  
  
Əgər media faylı (şəkil, audio, video) göndərilibsə, bridge.py həmin faylı groq_modules.py vasitəsilə emal edir (məs: şəkil üçün caption/OCR, audio üçün transkript). Alınan nəticə cavab mətnində uyğun etiket ilə göstərilir. Məsələn, audio üçün cavabın əvvəlində "(AUDIO)", şəkil üçün "(PHOTO)", video üçün "(VIDEO)" qeydi olunmalıdır ki, istifadəçi cavabın nəyə aid olduğunu anlasın.  
  
Lokasiya (location) tipli mesaj gəldikdə, WhatsApp WebJS modulu originalContent sahəsində koordinatları JSON kimi göndərir. Sistem bu koordinatları parsing edir və cavabda həmin nöqtəyə ən yaxın servis mərkəzinin ünvanını göstərir. Həmçinin koordinatların özünü də (enlem, boylam) cavab mətnində qeyd edir.  
  
İstənilən cavab strukturca həmişə JSON formatında qaytarılır, əsas açar reply olmalıdır. Məsələn, tipik cavab forması: {"reply": "Burada cavab mətni"}. Bu JSON format bridge.py tərəfindən WhatsApp API-ə göndərilməzdən əvvəl formalaşdırılır.  
  
Əgər generasiya olunmuş cavab mətni boş gələrsə və ya heç bir nəticə tapılmazsa (məsələn, tanınmayan sorğu və ya boş model cavabı), sistem əvəzedici cavab (fallback message) göndərməlidir. Bu, istifadəçiyə anlaşılmayan sorğu olduğunu və ya kömək mesajını bildirən hazır bir mətndir.  
  
Sistem işə düşərkən .env faylındakı bütün Groq API açarları yoxlanılır. Yoxlama prosesində hər bir API açarı ilə sadə bir test sorğusu göndərilir (məsələn, “ping” və ya kiçik bir emal əməliyyatı) və nəticəsi terminalda göstərilir. Uğurlu açarlar üçün yaşıl (OK) status, səhv olanlar üçün qırmızı (error) status çıxmalıdır. Bu, adminin konfiqurasiyanı düzgün qurub-qurmadığını asanlıqla yoxlaması üçün nəzərdə tutulur.  
  
user_contexts qovluğundakı tarixçə faylları dialoqun kontekstini tam saxlamalıdır. Xüsusilə, media mesajlarına verilən cavablar da (caption, transkript və s.) tarixçədə qeyd olunur ki, sonradan həmin cavabdan kontekstdə istifadə olunsun. Tarixçədə ardıcıllıq qorunmalı, hər bir giriş mesajı və çıxış cavabı növü (mətn, şəkil caption-u, audio transkripti və s.) ilə birlikdə saxlanılmalıdır.  
  
Məhsul axtarışı modulu fuzzy search (təxmini uyğunluqla axtarış) həyata keçirir. Yəni, istifadəçi məhsul adını tam düzgün yazmasa belə, sistem oxşar adlar arasında uyğun ola biləcək məhsulları tapmalıdır. Bu məqsədlə, məsələn, Levenshtein məsafəsi və ya uyğunluq faizindən istifadə olunur. Fuzzy axtarış sayəsində sistem istifadəçi sorğusuna tam uyğun gəlməyən nəticələri belə tapa bilir; bu metod bir çox axtarış sistemlərində istifadə olunur və yazılan sorğuya oxşar bir neçə variant təklif edir.  
İnteqrasiya olunmuş funksiyalar (get_product, get_product_price, get_product_stock, create_order) sorğuya uyğun olaraq müvafiq məlumatı CSV və ya DB-dən tapıb qaytarırlar. Bu funksiyaların hamısı düzgün işləməli, yəni mövcud məhsul ID-ləri ilə doğru qiymət və stok məlumatını verməli, create_order isə verilən məlumat əsasında sifariş obyektini yaradaraq təsdiq mesajı qaytarmalıdır.  
  
Yuxarıda sadalanan mövcud komponentlər və davranışlar hal-hazırda işlək vəziyyətdədir. Təkmilləşdirmə məqsədi, mövcud funksionallığı pozmadan, sistemi daha da intellektual, dəqiq və istifadəçi yönümlü etməkdir. Aşağıdakı bölmələrdə planlaşdırılan təkmilləşdirmələr və onların reallaşdırılması yolları ətraflı izah olunur.  
  
Təkmilləşdirmə Məqsədləri və Hədəfləri  
  
Təkmilləşdirmə planı beş əsas istiqaməti əhatə edir:  
  
Multimodal mesajlar üçün strukturlaşdırılmış cavablar – Şəkil, səs, video kimi multimodal sorğulara verilən cavabların daha aydın və struktur formada təqdim edilməsi.  
  
AI “Function Calling” və alətlərdən (tools) istifadə – Süni intellektə xarici funksiyaları çağırma imkanı verərək (məsələn, şəkil analizi, məhsul axtarışı və s. kimi mövcud funksiyaları AI vasitəsilə dinamik şəkildə işə salmaq), cavabların real vaxtda və daha ağıllı formada generasiyası.  
  
Yeni API açarları ilə işləmə qabiliyyəti – Sistemə yeni Groq (və ya digər) API açarları əlavə edildikdə, onların .env faylında saxlanılması və istifadəsi, eləcə də sistem startında avtomatik test mexanizminin təkmilləşdirilməsi.  
  
Promptların lokalizasiyası və ayrılması – Modelə verilən təlimatlar (system/user promptları) və şablon cavabların Azərbaycan dilinə tam uyğunlaşdırılması, həmçinin müxtəlif ssenarilər (məsələn, audio transkript, görüntü təsviri) üçün fərqli promptların ayrıca idarə olunması.  
  
Test menyusunun əlavə olunması – Bütün alt-sistemlərin (şəkil emalı, audio emalı, lokasiya, məhsul axtarışı, sifariş, API açarlarının yoxlanması və s.) inteqrasiya testlərini tez bir şəkildə həyata keçirmək üçün CLI və ya veb interfeys üzərindən rahat bir test menyusu hazırlanması.  
  
Aşağıdakı bölmələrdə hər bir istiqamət üzrə konkret dəyişiklik təklifləri, arxitekturadakı yeniliklər və nümunə implementasiya detallarına yer verilmişdir.  
  
1. Multimodal Mesajlar üçün Strukturlaşdırılmış Cavablar  
  
Multimodal mesaj dedikdə, mətndən əlavə şəkil, audio, video, lokasiya kimi tiplər nəzərdə tutulur. Mövcud sistem artıq bu tip mesajları emal edib cavab verir, lakin cavabların təqdimatı bəzi hallarda qarışıq ola bilər. Məsələn, istifadəçi bir şəkil göndərəndə həm onun təsvirini (caption), həm də içindəki mətni (OCR) alıb istifadəçiyə bircə sətirdə göndərmək mümkündür ki, bu da anlaşılmaz ola bilər. Təkmilləşdirmə məqsədimiz – hər media nəticəsinin ayrıca və aydın formatda çatdırılmasıdır.  
Bu dəyişikliyi həyata keçirmək üçün groq_modules.py və bridge.py modullarında yeniliklər ediləcək:  
  
groq_modules.py dəyişiklikləri: Şəkil emalı funksiyası hal-hazırda bir şəkil üçün həm təsvir generasiyası, həm də OCR edirsə, bu nəticələri ayrı dəyişənlərdə saxlamalıdır (məsələn, caption_text və ocr_text). Əgər hal-hazırda yalnız biri edilibsə (məsələn, təkcə caption), onda modul genişləndirilib həm də OCR nəticəsini ala bilməlidir. Audio üçün transkript mətni, video üçün həm səs transkripti, həm də videodan alınan hər-hansı təsvir (məs: videonun ilk kadra dair caption) ayrı-ayrı alınmalıdır. Nəticələr bir struktur (məsələn, dict) formasında bridge.py-yə qaytarılmalıdır. Misal üçün, şəkil üçün emal funksiyası aşağıdakı kimi nəticə qaytara bilər:  
  
# groq_modules.py daxilində şəkil emalı funksiyası üçün nümunə def process_image(file_path): caption_text = groq_api.generate_caption(file_path) ocr_text = groq_api.perform_ocr(file_path) result = { "caption": caption_text, "ocr": ocr_text } return result   
  
bridge.py dəyişiklikləri: bridge.py modulunda, şəkil sorğusunun cavabını formalaşdıran hissə artıq groq_modules.py-dən gələn struktur nəticə ilə işləyəcək. Burada cavab mətnini formalaşdırarkən, ayrı sahələri xüsusi etiketlərlə qeyd etməliyik. Məsələn, yuxarıdakı nəticəyə əsasən:  
  
result = process_image(image_file) caption = result.get("caption") ocr_text = result.get("ocr") reply_text = "" if caption: reply_text += f"(PHOTO) Təsvir: {caption}\n" if ocr_text: reply_text += f"(PHOTO) Mətndə aşkarlanan: {ocr_text}\n" response = {"reply": reply_text.strip()}   
Bu nümunədə, şəkil üçün cavab iki sətirlik olacaq: birinci sətirdə "(PHOTO) Təsvir: ..." şəklində modelin yaratdığı caption, ikinci sətirdə "(PHOTO) Mətndə aşkarlanan: ..." şəklində OCR mətni. Eyni prinsip audio və video üçün də tətbiq ediləcək:  
  
Audio mesajlar üçün: (AUDIO) Transkript: ... yalnız bir sətir (səsdəki nitqin mətnə çevrilməsi).  
  
Video mesajlar üçün: mümkün nəticələr iki yerə ayrılar – (VIDEO) Səs transkript: ... və əgər video analizi (məsələn, ilk kadrın təsviri və ya kollaj analizi) varsa, (VIDEO) Təsvir: ....  
  
Lokasiya mesajı üçün: Cavabda həm koordinatlar, həm də ünvan göstərilir, məsələn: (LOCATION) Koordinatlar: 40.4093, 49.8671 – Ən yaxın servis mərkəzi: PierringShot Nizami filialı, Nizami küçəsi 1234.  
  
Formatlama və Oxunaqlılıq: Cavab mətni multi-line (çoxsətirli) ola bilər, lakin WhatsApp mesajlarında çoxsətir dəstəkləndiyi üçün problem yaratmır. Əsas odur ki, hər sətir öz nəticəsini ehtiva etsin və önündə uyğun media etiketi olsun. İstifadəçi üçün mesajın hansı hissəsinin hansı media nəticəsi olduğu tam aydın olacaq.  
  
JSON Cavab Şablonu: Yekun cavab yenə də {"reply": "...\n...\n"} formatında JSON-dur. Burada reply dəyəri içində yeni sətirlər ola bilər. Bu şablonu sənədləşdirmək və gələcəkdə dəyişiklik olarsa asan düzəltmək üçün, sistemdə bir cavab şablonları sözlüyü saxlamaq olar. Məsələn, bir Python lüğətində media tiplərinə uyğun cavab formatlarını öncədən təyin etmək:  
RESPONSE_TEMPLATES = { "photo": "(PHOTO) Təsvir: {caption}\n(PHOTO) Mətndə aşkarlanan: {ocr}", "audio": "(AUDIO) Transkript: {text}", "video": "(VIDEO) Səs transkript: {audio_text}\n(VIDEO) Təsvir: {video_caption}", # ... }   
Sonra bridge.py bu şablonlardan uyğun olanını seçib .format() ilə doldura bilər. Bu yanaşma cavab formatlarını mərkəzləşdirilmiş şəkildə idarə etməyə imkan verər.  
  
User Context Yaddaşı: Strukturlaşdırılmış cavablar eyni zamanda user_contexts/ tarixçəsinə də eyni formatda yazılmalıdır. Yəni, əgər istifadəçi şəkil göndəribsə, context faylında cavab kimi ayrı-ayrılıqda caption və OCR-in mətnləri görünəcək. Bu, gələcək mesajlarda kontekst istifadəsini yaxşılaşdıracaq (məsələn, istifadəçi "bu mətnin mənası nədir?" deyə soruşsa, sistem tarixçədən son OCR mətnini görüb anlaya biləcək ki, bu suala cavab vermək üçün mətn tərcüməsi və ya izahı lazımdır).  
  
Nümunə: İstifadəçi bir məhsul fotosu göndərir və altına "Bu məhsulun qiyməti?" yazır. Sistem əvvəlcə şəkili emal edib caption və OCR alır. Tutalım caption: "qutuda elektronika məhsulu", OCR: "Model ABC123". Sonra istifadəçinin sorğusunu da nəzərə alıb cavab formalaşdırır:  
{ "reply": "(PHOTO) Təsvir: qutuda elektronika məhsulu\n(PHOTO) Mətndə aşkarlanan: Model ABC123\nBu, ABC123 modelinin qiyməti 250 AZN-dir. Sifariş etmək istəsəniz, \"Sifariş et\" deyə bilərsiniz." }   
Burada ilk iki sətir strukturlaşdırılmış multimedia məlumatıdır, davamında isə məhsulun qiyməti haqqında məlumat verilmişdir. Bu cür strukturlaşdırma cavabın texniki cəhətdən dolğun və oxucu üçün rahat olmasını təmin edir.  
  
2. Süni İntellekt tərəfindən Funksiya Çağırışı (Function Calling) və Alətlərdən İstifadə  
  
Sistemin intellektuallaşdırılması üçün planlanan ən mühüm addımlardan biri, süni intellektin özü müxtəlif modulları və funksiyaları lazım olduqda avtomatik çağırıb istifadə edə bilməsidir. Hal-hazırda bridge.py daxilində qərar mexanizmi statik kodla müəyyən edilir (if/else strukturları ilə mesaj tipinə görə hansı funksiyanın çağrılacağı yazılıb). Bu yanaşma işə yarasa da, gələcəkdə daha mürəkkəb dialoqlarda və ya çox addımlı tapşırıqlarda məhdudiyyət yarada bilər. Məsələn, istifadəçi eyni anda həm şəkil göndərib, həm "bu məhsulu sifariş et" deyə bilər; bu halda həm caption/OCR, həm də məhsul axtarışı funksiyalarını koordinasiya etməyə ehtiyac var. Bu koordinasiyanı daha ağıllı şəkildə həll etmək üçün AI agent yanaşmasını və function calling imkanlarını daxil edirik.  
Function Calling konsepti: Yeni nəsil dil modelləri (xüsusilə OpenAI GPT-4 və b.) xarici funksiyaların çağırışını dəstəkləyir. Bu o deməkdir ki, modelə müəyyən formatda funksiyaların imzasını (adı, parametrləri və nə iş gördüyünü) ötürürük və model istifadəçinin sorğusuna əsasən, əgər ehtiyac görərsə həmin funksiyalardan birini zəng etmək (call) üçün strukturlaşdırılmış cavab qaytarır. Sonra proqram həmin funksiyanı icra edir və nəticəsini yenə modelə verə bilir. Bu döngü vasitəsilə model bir neçə addımda müxtəlif alətlərdən istifadə edərək tapşırığı icra edə bilir. Məsələn, GPT-4 Vision modeli function calling ilə birgə işlədikdə, təkcə OCR edib təsviri qaytarmaqla kifayətlənmir, eyni zamanda görüntüdən çıxardığı məlumat əsasında məntiqi nəticələr çıxarıb qərarlar verə bilir.  
Bizim sistemdə function calling tətbiq etmək üçün aşağıdakı addımlar planlaşdırılıb:  
  
Mövcud funksiyaların abstraksiyası: İlk olaraq, sistemdə mövcud olan bütün mühüm əməliyyatları funksiya kimi modelə tanıtmaq lazımdır. Məsələn:  
  
caption_image(image_path) -> {"caption": str, "ocr": str} – Şəkil emal funksiyası.  
  
transcribe_audio(audio_path) -> {"text": str} – Audio transkripti funksiyası.  
  
analyze_video(video_path) -> {"audio_text": str, "video_caption": str} – Video emal funksiyası.  
  
search_product(query: str) -> {"products": list} – Məhsul axtarışı (fuzzy uyğunluqla).  
  
get_product_details(product_id: str) -> {"price": float, "stock": int} – Məhsulun qiyməti və stoku üçün.  
  
place_order(product_id: str, user_info: dict) -> {"order_id": str, "status": str} – Sifariş yaratmaq funksiyası.  
  
Və s. (lazım olduqca digər alət funksiyalarını da əlavə edə bilərik).  
  
Hər funksiyanın bir şema tərifi olmalıdır: adı, qəbul etdiyi parametrlər (və tipləri), qaytardığı nəticə strukturu (JSON formatında). Bu təriflər bir JSON siyahısı və ya Python dict-i şəklində dil modelinə ötürüləcək. Məsələn, OpenAI API istifadə olunarsa, functions parametrində bu tərifləri vermək mümkündür.  
  
Model inteqrasiyası: bridge.py modulunda hazırkı if/else əsaslı yönləndirmə qismən ləğv edilərək, onun yerinə AI agent inteqrasiyası gəlir. Məsələn, istifadəçi mesaj göndərəndə:  
  
Əvvəlcə bridge.py müvafiq mediadan lazımi məlumatı yığa bilər (məs: şəkil varsa, öncə caption+OCR əldə edib modelə həm mətn, həm şəkil məlumatı verə bilər). Alternativ yanaşma olaraq, media faylını birbaşa modelə də vermək olar əgər model onu qəbul edirsə (GPT-4 Vision kimi modellər üçün mümkündür).  
  
Modelə sistem prompt-u, istifadəçi prompt-u və funksiyaların siyahısı göndərilir. Sistem prompt-u modelə bu platformanın qaydalarını izah edir (məsələn: “Sən PierringShot Electronics botusan, sorğuları cavablandır və lazım gələrsə funksiyaları çağır.”), user prompt isə istifadəçi mesajının məzmunudur (burada media haqqında meta-məlumat da ola bilər).  
  
Model cavabı ya birbaşa istifadəçiyə göndəriləcək mətn olur, ya da xüsusi formatda function_call olur. Məsələn, model belə bir JSON cavab verə bilər: { "function_call": { "name": "search_product", "arguments": "{ \"query\": \"ABC123\" }" } } Bu, modelin search_product funksiyasını çağırmaq istədiyini göstərir. bridge.py bu cavabı aldıqdan sonra müvafiq funksiyanı (csv_search.py içində) real olaraq icra edir. Nəticəni (məsələn, məhsul siyahısını JSON olaraq) geri modelə ötürür.  
  
Model ikinci dəfə nəticəni alıb yenidən işləyir və final cavabı generasiya edir. Bu cavab da eyni qayda ilə JSON formatında (bizim sistem üçün `{"reply": "..."} formatında) olacaq.  
  
Funksiya Çağırışı Axınının Reallaşdırılması: Bu çoxaddımlı prosesi idarə etmək üçün bridge.py daha mürəkkəb dialoq idarəetməsi etməlidir. Psevdo-kod səviyyəsində:  
user_message = receive_message() media = user_message.media # varsa, media faylı text = user_message.text # istifadəçi mətn sorğusu (olmaya da bilər, tək media göndəribsə) # 1. Media varsa, ön emal (məsələn, caption/OCR) media_info = {} if media: media_info = groq_modules.process(media) # Məsələn, media_info = {"caption": "...", "ocr": "..."} şəkil üçün # 2. Modelə hazırlıq: promptları qur system_prompt = get_system_prompt() # .env-dən və ya ayrıca fayldan oxunur user_prompt = create_user_prompt(text, media_info) functions_def = get_functions_definitions() # mövcud funksiyalar # 3. Model çağırışı model_response = llm.call(prompt=[system_prompt, user_prompt], functions=functions_def) # 4. Əgər model bir funksiya çağırışı qaytardısa: if model_response.get("function_call"): func_name = model_response["function_call"]["name"] args = json.loads(model_response["function_call"]["arguments"]) func_result = execute_function(func_name, args) # müvafiq modulu çağır, nəticə al # Nəticəni modelə yenidən ver model_response = llm.call(prompt=[system_prompt, user_prompt, func_result], functions=functions_def) # 5. İndi model_response final cavab olmalıdır final_text = model_response["content"] send_response({"reply": final_text})   
Yuxarıda, sadəlik üçün yalnız bir dəfə funksiya çağırışı edilib. Əslində model bir neçə dəfə ardıcıl funksiya çağırışı tələb edə bilər, buna görə while dövrü ilə son cavab alınana qədər təkrarlamaq olar. Həmçinin, func_result modelə ötürülərkən onu ayrıca bir "assistant" mesajı kimi ötürmək (funksiyanın nəticəsi haqqında prompt) lazımdır ki, model bunu növbəti cavabında nəzərə alsın.  
  
Groq Alətlərinin Uyğunlaşdırılması: Bizim xüsusi halda, LLM (Large Language Model) olaraq bəlkə də Groq platformasının təqdim etdiyi Llama 3.2 və ya GPT-4 bənzəri bir modeldən istifadə ediləcək. Vacib nüans: əgər Groq API vasitəsilə model çağırırıqsa, o da function call nəticəsini JSON qaytara bilməlidir və ya biz JSON parse etməliyik. Alternativ, OpenAI API-dən GPT-4 istifadə etmək də variantdır (bunun üçün əlavə API açar lazım olacaq). Hər iki halda, modullarımız (şəkil, audio emalı və s.) "tool" kimi modelin istifadəsinə verilir.  
  
Arxitektur Dəyişiklikləri: Bu yenilik nəticəsində arxitektura bir qədər dəyişəcək. Əvvəlki kimi wwebjs_listener.js mesajları qarşılayıb bridge.py-yə göndərir. Əsas dəyişiklik bridge.py-nin daxili işindədir: statik əmr icra edən bir serverdən AI agent yönləndiricisinə çevrilir. Bu, modulyar şəkildə reallaşdırılacaq ki, lazım gələrsə function calling rejimini deaktiv edib yenə sadə rejimə keçmək olsun. Məsələn, .env-də USE_AI_AGENT=true/false parametri qoyula bilər. Test mərhələsində bu açarı false edib köhnə if/else mexanizmi ilə müqayisəli test aparmaq yaxşıdır.  
  
Function Calling-dən qazanc: Bu inteqrasiya sayəsində sistem daha çevik olacaq. İstifadəçi kompleks sorğu göndərəndə model özü qərar verəcək ki, hansı alətlər lazımdır. Məsələn, istifadəçi şəkil göndərib "bu cihaz nədir və stokda varmı?" deyə soruşarsa, model öncə caption_image edəcək, sonra caption nəticəsindəki məhsul adına əsasən search_product funksiyasını çağıracaq, ardınca stok məlumatı üçün bəlkə get_product_stock çağıracaq və sonda bütöv bir cavab hazırlayıb user-a göndərəcək. Bütün bu prosesi AI özü planlaşdıracaq. Bu yanaşma müasir AI sistemlərinin trendinə uyğundur və multimodal kontekstdə çox güclü imkanlar yaradır.  
  
3. Yeni API Açarlarının İnteqrasiyası və .env İdarəsi  
  
Sistemdə hal-hazırda bir neçə API açarı istifadə olunur (Groq API üçün, bəlkə WhatsApp API üçün token, bəlkə OpenAI açarı və s.). Təkmilləşdirmə planında qeyd olunub ki, yeni API açarları istifadəyə veriləcək və yalnız istifadəçi tərəfindən təqdim edilən (yenilənmiş) açarlar işlək olmalıdır. Bu, bir neçə məqamı ehtiva edir:  
  
.env Faylının Yenilənməsi: Yeni açarlar təqdim olunduqda onlar .env faylına əlavə ediləcək. Məsələn, hal-hazırda .env-də  
{ "GROQ_API_KEY": "xxxxx", "GROQ_IMAGE_MODEL": "llama-3.2-vision", "GROQ_AUDIO_MODEL": "whisper-1.0", "WHATSAPP_TOKEN": "abcd1234", ... }   
kimi parametrlər ola bilər. İndi əgər OpenAI GPT-4 API açarı əlavə olunacaqsa, onu da ora yazmaq lazımdır: "OPENAI_API_KEY": "sk-...". Sistem elə dizayn edilməlidir ki, .env faylındakı bu açarlar avtomatik oxunur və müvafiq modullara ötürülür. Məsələn, groq_modules.py Groq açarını os.getenv("GROQ_API_KEY") ilə almalıdır. Yeni açarlar üçün də eyni praktika tətbiq edilməlidir – hardkod etmək əvəzinə konfiqurasiya oxunmalıdır.  
  
JSON vs dotenv formatı: Qeyd edək, .env “JSON formatında” saxlanılır deyə qeyd edilib. Ola bilər .env əslində .json faylıdır və ya environment variable-ların olduğu bir fayldır. Dəqiqləşdirmək lazımdır; amma hər iki halda, yeni açarları əlavə edərkən formatı pozmamaq önəmlidir. Əgər .env sırf sətir-sətir KEY=VALUE formasındadırsa, yeni açarı həmin formata uyğun əlavə etmək lazımdır. Yox əgər JSON-dursa, JSON sintaksisinə uyğun əlavə olunmalıdır.  
  
Açarların Yoxlanılması (Health Check): Mövcud sistem startup zamanı açarları test edirdi. Bu funksiyanı genişləndirib yeni açarları da testə daxil etmək gərəkdir. Hər API üçün fərqli test üsulu ola bilər:  
  
Groq API açarı: Kiçik bir sorğu (məs: model siyahısını çəkmək və ya sadə bir prompt göndərmək) göndərilərək açarın keçərli olub-olmadığı yoxlanır. Cavab 200 OK və ya gözlənilən strukturda gəlməzsə, demək açar etibarsızdır.  
  
OpenAI API açarı (yeni inteqrasiya olunacaqsa): Məsələn, "GPT-4 modelinə boş bir sorğu göndər və cavab al" və ya sadəcə açarın formatını yoxla. OpenAI açarı səhv olarsa adətən 401 cavabı gələr.  
  
Hər hansı digər xidmət açarları: WhatsApp tokeni, Memento DB və s. Onları da test etmək üçün bəlkə meta məlumat sorğusu və ya sadə bağlantı sorğusu atıla bilər.  
  
Sistem başlanğıcında bu testlər ardıcıl aparılmalı və terminala aydın şəkildə log yazılmalıdır. Məsələn:  
[INIT] GROQ_API_KEY yoxlanılır... OK [INIT] OPENAI_API_KEY yoxlanılır... OK [INIT] WHATSAPP_TOKEN yoxlanılır... ERROR (etibarsız token)   
Belə bir çıxış administratorun dərhal hansı açarda problem olduğunu bilməsinə imkan verər. Bu mesajlar rəngli çıxırdı (yaşıl/qırmızı). Terminala rəngli mətn çıxarmaq üçün Python-da colorama kitabxanasından istifadə oluna bilər, və ya sadəcə ASCII ilə (✔ ✘ işarələri ilə) göstərilə bilər.  
  
Yeni Açarların Sistemə Təsiri: Xüsusilə, yeni açarlar dedikdə böyük ehtimalla yeni model inteqrasiyası nəzərdə tutulur. Yuxarıda function calling üçün OpenAI GPT-4 mention edilib. Bu reallaşdırılacaqsa, .env-də OPENAI_API_KEY, OPENAI_MODEL_NAME (məsələn, gpt-4-0613 kimi) kimi parametrlər olmalıdır. bridge.py bu açarları oxuyub OpenAI API client-i initialize etməlidir. Eyni zamanda, Groq tərəfindən təqdim edilən yenilənmiş modellər də ola bilər (məsələn, Llama 3.2-dən 3.3-ə keçid), onların da yeni id-ləri .env-də yenilənməlidir.  
  
Güvənlik: Açarlar .env-də saxlanılır deyə kod repozitoriyasından kənarda olmalıdır (git-ignore). Sənəddə açarların adları çəkişir, lakin dəyərlər heç bir yerdə loqlanmır və ya paylaşımlarda göstərilmir. Bu standartlara əməl olunmalıdır. Test edərkən də, uğursuz test zamanı açarın özünü göstərmək olmaz, sadəcə adı və statusu yetərlidir.  
  
Geriyə Uyğunluq (Backward Compatibility): Sistemdə hal-hazırda işləyən açarlar və funksiyalar qalmalıdır. Yeni açarlar əlavə olunması köhnə konfiqurasiyanı pozmamalıdır. Məsələn, əgər OpenAI açarı verməsək belə, sistem yenə Groq modeliylə (function calling olmadan) işləməyə davam etməlidir. Bu məqsədlə kodda şərtlər olacaq: əgər filan açar mövcuddursa, yeni funksiyanı aktiv et, yoxdursa, köhnə rejimdə çalış. Bu, mərhələli keçid üçün vacibdir.  
  
Yekun olaraq, .env idarəetməsi ilə bağlı təkmilləşdirmələr sistemin konfiqurasiyasını daha çevik edir. Yeni açarların sadəcə fayla əlavə olunması ilə sistemin eyni kod bazası ilə fərqli modları (məs: fərqli AI provayderi) dəstəkləməsi mümkün olacaq. Bu da gələcəkdə sistemin miqyaslanması və digər servislərə inteqrasiyası üçün önəmli bir hazırlıqdır.  
  
4. Promptların Lokalizasiyası və Strukturlaşdırılması  
  
İstifadəçi ilə AI modelinin uğurlu ünsiyyəti üçün prompt mətnləri (yəni modelə verilən təlimat və kontekst) həlledici rola malikdir. Bu bölmədə sistemdə istifadə olunan müxtəlif prompt növlərinin (sistem promptu, istifadəçi promptu, media ilə bağlı promptlar və s.) necə lokalizasiya olunacağı (Azərbaycan dilinə və istifadəçinin anlayacağı formaya uyğunlaşdırılacağı) və idarə ediləcəyi müzakirə olunur. Məqsəd odur ki, modelin cavabları dəqiq olsun, verilən təlimatlara uyğun çıxsın və hər bir dil-texniki incəlik nəzərə alınsın.  
Mövcud sistemdə mümkündür ki:  
  
Sistem promptu (yəni modelin rolunu müəyyən edən və ümumi davranış qaydalarını izah edən mətn) hardcoded formada İngilis dilində olsun və ya ümumiyyətlə minimal olsun.  
  
Audio və görüntü üçün ayrıca model promptları ola bilər (məsələn, "Bu səsi transkript et" kimi).  
  
İstifadəçinin sorğusu sadəcə özünə verilir, əlavə kontekst az verilir.  
  
Təkmilləşdirmə addımları:  
  
Promptların Kateqoriyalara Ayrılması: Əvvəlcə, fərqli situasiyalar üçün istifadə olunan promptları müəyyən edib ayrı saxlamaq lazımdır:  
  
Sistem Promptu: Bütün dialoq boyunca modelin rolunu təyin edir. Məsələn, "Sən PierringShot Electronics şirkətinin səsli köməkçisisən. İstifadəçilərin suallarına Azərbaycan dilində, nəzakətli və dəqiq cavablar verirsən. Sənin bacarıqlarına şəkil təsviri, audio transkripti, məhsul məlumat bazasında axtarış və s. daxildir." kimi bir məzmun. Bu prompt mümkün qədər əhatəli olmalıdır ki, model icazə verilməyən mövzulara girməsin və mövzunu daima biznes kontekstdə saxlasın.  
  
İstifadəçi Promptu Şablonu: İstifadəçinin mesajını modelə ötürmədən öncə bəzən biz ona kontekst əlavə edə bilərik. Xüsusən, multimodal mesajlarda. Məsələn, istifadəçi sadəcə bir şəkil göndəribsə heç mətn yoxdur, amma modelə yenə "user" mesajı vermək lazımdır. Bu halda, user promptuna "İstifadəçi sizə bir şəkil göndərdi." kimi bir cümlə əlavə edib, sonra şəkilin təsviri/OCR nəticəsini də orada qeyd edə bilərik ki, model onu sanki istifadəçi deyirmiş kimi qəbul etsin. Bunu düzgün formalaşdırmaq vacibdir ki, model çaşmasın. Məsələn:   
  
Əgər şəkil göndərilibsə və caption/OCR alınıbsa: "<image_description>: ... <image_text>: ... . İstifadəçi soruşur: Bu nədir?" kimi kombinə bir prompt yaradıb modelə user mesajı kimi vermək olar.  
  
Əgər audio göndərilibsə: "İstifadəçi səsli mesaj göndərdi, mətn transkripti: '...'" kimi.  
  
Bunları daha yaxşı idarə etmək üçün ayrıca media prompt şablonları tərtib olunur. Məsələn: MEDIA_PROMPTS = { "photo": "İstifadəçi şəkil göndərib. Şəkilin təsviri: \"{caption}\". Şəkildəki mətn: \"{ocr}\".", "audio": "İstifadəçi audio göndərib. Audio transkript: \"{text}\".", "video": "İstifadəçi video göndərib. Videodan çıxan səs mətni: \"{audio_text}\". Video görüntü təsviri: \"{video_caption}\"." } Sonra bridge.py modelə user mesajını quranda, əgər media varsa, bu şablona uyğun mətni formalaşdıracaq. Bunun ardınca, istifadəçinin mətn sorğusu (əgər əlavə sual yazıbsa) gəlir. Onu da əlavə edib tam user prompt yaradır.  
  
Funksiya (Tool) Promptları: Function calling istifadə olunursa, modelə verilən funksiyaların təsviri də bir növ promptdur. Onların təsvirini da lokalizasiya etmək faydalıdır. Məsələn, search_product funksiyasının təsviri "Axtarış funksiyası: verilən sorğuya əsasən məhsul bazasında uyğun məhsulları tapır və siyahısını qaytarır." kimi Azərbaycan dilində yazılsa, modelin bunu anlaması (xüsusən Azərbaycan dilində sorğu verilirsə) daha təbii olar. Hal-hazırda OpenAI-nin function calling interfeysində funksiyanın təsvirini ingiliscə vermək qəbul olunmuş praktika olsa da, bizim halda model lokal (Groq Llama kimi) ola bilər deyə, təsviri doğrudan Azərbaycan dilində saxlamaq uyğundur. Bütün funksiyalar üçün JSON tərifdə description sahəsi lokalizasiya ediləcək.  
  
Promptların Fayllarda saxlanması: Kodun səliqəli olması üçün bu cür uzun promptları birbaşa python kodunda saxlamaq yerinə, ayrıca fayllara qoymaq faydalı ola bilər. Məsələn:  
  
prompts/system.txt – sistem promptu mətni.  
  
prompts/user_media.txt – media üçün şablonlar (burada placeholder-lar göstərilə bilər).  
  
prompts/functions.json – funksiyaların adları, parametrləri və təsvirləri (lokal dildə). Bu fayllar .env ilə birlikdə saxlanıb, yüklənərkən oxunacaq. Belə olduqda, promptları düzəltmək üçün kodu dəyişməyə ehtiyac olmayacaq, sadəcə faylları redaktə etməklə yenilənmiş promptlar tətbiq ediləcək.  
  
Azərbaycan dilinə tam uyğunlaşdırma: Prompt mətnlərinin lokalizasiyası təkcə dil məsələsi deyil, həm də ton və terminologiya məsələsidir. Azərbaycan dilində texniki cavablar verən botun nitqi nə çox səmimi (məs: "qaqa, bunun qiyməti..." olmaz), nə də çox rəsmi ("Hörmətli müştəri..." hər cavabda lazım deyil) olmalıdır. Sistem promptunda bu balans müəyyən edilməlidir. Məsələn, "Sən istifadəçilə səmimi, amma işgüzar dildə danışırsan. Çox uzun cümlələr qurma, mümkünsə maddələr və ya qısa cümlələrlə izah et." kimi təlimatlar yazıla bilər.  
  
Məlumatların Dəqiqliyi: Promptlarda modelə deyilir ki, əgər cavab üçün lazımi informasiya funksiyalardan gəlməsə, özü uydurmasın. Məsələn, "Məlumat əmin olmadıqda function call et" tipli bir təlimat vermək olar. Bu da promptun bir hissəsi ola bilər. Həmçinin, model cavabının sonunda mütləq {"reply": "..."} formatında JSON qaytarmalı olduğunu başa düşməlidir. Bu məqsədlə, sistem promptuna cavab formatı haqqında təlimat əlavə etmək olar (məsələn: "Cavabı yalnız JSON formatında və reply açarı altında ver").  
  
Test və Təkmilləşdirmə: Promptlar AI sistemlərinin incə tənzimlənməsi (fine-tuning) kimidir; yəni bir neçə iterasiya tələb edə bilər. İlk versiyadan sonra, test mesajları göndərib modelin davranışı müşahidə olunmalıdır: Azərbaycan dilində cavab verirmi, istənilən formatı qoruyurmu, funksiyaları çağırırmı, yalnış məlumat verməyə cəhd edirmi və s. Bu test nəticələrinə əsasən prompt mətnlərində düzəlişlər etmək lazım gələcək. Misal üçün, modelin cavabında ingiliscə sözlər görünərsə, demək daha sərt lokalizasiya təlimatı əlavə etmək lazımdır ("Bütün cavab tamamilə Azərbaycan dilində olmalıdır" kimi).  
  
Nəticə etibarilə, bu bölmədəki dəyişikliklər sistemin “beyni” olan AI modelinin düzgün yönləndirilməsini təmin edəcək. Lokal dildə incə tənzimlənmiş promptlar modelin verdiyi cavabların keyfiyyətini yüksəldəcək, funksional modullarla inteqrasiyasını daha rəvan edəcək və istifadəçi təcrübəsini yaxşılaşdıracaq.  
  
5. Test Menyusunun Əlavə Edilməsi və Avtomatlaşdırılmış Yoxlamalar  
  
Sistemin bir çox funksional hissələri olduğu üçün (şəkil emalı, audio emalı, lokasiya emalı, məhsul axtarışı, sifariş, API açarları və s.), onları ayrı-ayrılıqda və bütöv inteqrasiya halında sınamaq vacibdir. Təkmilləşdirmə planının sonuncu hissəsi, test menyusunun hazırlanmasıdır. Bu, developer-ə və ya sistem administratoruna imkan verəcək ki, xüsusi komandalar və ya interfeys vasitəsilə müxtəlif testləri asanlıqla işə salsın və nəticələri görsün.  
İki əsas yanaşma mümkündür:  
  
CLI (Command-Line Interface) üzərindən test menyusu,  
  
və ya Web interfeys (məsələn, əlavə bir endpoint və sadə HTML səhifəsi vasitəsilə).  
  
Bu sənəddə CLI yanaşması nümunə ilə izah olunacaq, çünki server kontekstində tez-tez bu rahat olur.  
Test Menyusunun Strukturu: Test menyusu, menyu bəndlərindən ibarət bir siyahıdır. Məsələn, konsola python test_menu.py yazdıqda aşağıdakı kimi seçimlər çıxa bilər:  
Test Menyusuna Xoş Gəldiniz: 1. Şəkil emalı test et (caption + OCR) 2. Audio transkript test et 3. Lokasiya sorğusu test et 4. Məhsul axtarışı test et 5. Sifariş yaratma test et 6. Bütün API açarlarını yoxla (Health Check) 7. Bütöv sistem dialoq testi 0. Çıxış Seçiminizi edin (0-7):   
Burada hər bir seçim müəyyən bir test ssenarisini işə salar.  
Test Ssenariləri və Reallaşdırma:  
  
Şəkil Emalı Testi: Bu test üçün öncədən bir sınaq şəkili faylı olmalıdır (məsələn, test_data/test_image.jpg). Menyudan 1 seçiləndə, proqram groq_modules.py içindəki şəkil emalı funksiyasını birbaşa çağırır. Alınan caption və OCR nəticəsini konsola çıxarır. Daha sonra, formatlama funksiyasını (yuxarıda 1-ci bölmədə izah olunan cavab formalaşdırılması) da tətbiq edərək, JSON cavabı kimi nə çıxacağını göstərir. Misal:  
[TEST] Şəkil emalı nəticəsi: Caption: qutu üzərində elektron cihaz OCR: Model: XYZ123 JSON cavab nümunəsi: {"reply": "(PHOTO) Təsvir: qutu üzərində elektron cihaz\n(PHOTO) Mətndə aşkarlanan: Model: XYZ123"}   
Bu, developer-ə hem modulu, hem də formatı yoxlamağa imkan verər.  
  
Audio Transkript Testi: Sınaq üçün qısa bir audio faylı (test_data/test_audio.ogg və ya .wav) istifadə olunur. Menyu 2 seçiləndə, groq_modules.py-nin audio transkript funksiyası çağırılır və nəticə (məsələn, "Salam, necəsiniz") çıxarılır. Daha sonra JSON cavab {"reply": "(AUDIO) Transkript: Salam, necəsiniz"} şəklində formalaşdırılıb göstərilir.  
  
Lokasiya Sorğusu Testi: Burada sınaq məqsədilə bəzi koordinatlar əvvəlcədən verilir (məsələn, Bakı şəhərinin mərkəzi: lat=40.4093, lon=49.8671). Menyu 3 seçiləndə proqram sanki wwebjs_listenerdən lokasiya mesajı gəlib kimi bridge.py funksiyasını çağırır. Bu funksiya (yaxud ayrıca bir modul) həmin koordinatları götürüb bir funksiya vasitəsilə ən yaxın servis ünvanını tapmalıdır. Əgər belə bir funksiya artıq varsa (get_nearest_location(lat, lon) kimi), onu test edir, yoxdursa, bəlkə Google Maps API və ya statik bir siyahı vasitəsilə nümunə üçün bir nəticə qaytarır. Testin nəticəsi konsolda belə görünə bilər:  
[TEST] Lokasiya sorğusu: Giriş: lat=40.4093, lon=49.8671 Çıxış cavab: {"reply": "(LOCATION) Koordinatlar: 40.4093, 49.8671 - Ən yaxın servis: Baki Səbail filialı, İçərişəhər"}   
(Ünvan uydurmadır misal üçün).  
  
Məhsul Axtarışı Testi: Bu, csv_search.py modulunun funksiyalarını sınayacaq. Menyu 4 seçiləndə, proqram daxilində bir neçə sınaq sorğusu işlədilə bilər:  
  
Məsələn: search_product("iPhone 13") – nəticədə bir siyahı gəlməlidir (bəlkə CSV-dən bir sətir).  
  
get_product_price("ABC123") – müəyyən ID-li məhsulun qiymətini qaytarır.  
  
get_product_stock("ABC123") – stokda qalan sayını qaytarır. Bu test, həm də fuzzy search’un işlədiyini yoxlayar. Məsələn, CSV-də "Samsung Galaxy S21" varsa, amma sorğu "Sansung S21" yazılıbsa, yenə tapılırmı? Test funksiyası bir neçə belə case-ləri yoxlamalıdır. Konsol çıxışı:  
  
[TEST] Məhsul axtarışı: Sorğu: "Sansung S21" Tapılan ən yaxın məhsul: Samsung Galaxy S21 (ID: SG21) Qiyməti: 1500 AZN, Stok: 3 ədəd   
Bu şəkildə ardıcıl addımlarla göstərilə bilər. Əlavə olaraq, final JSON cavab formatına da baxmaq olar, əgər birbaşa bridge.py inteqrasiyasını test edirlərsə.  
  
Sifariş Yaratma Testi: Menyu 5 seçiləndə, sistem sınaq məqsədli bir sifariş əməliyyatı aparmalıdır. Məsələn, yuxarıda tapılan "SG21" məhsulunu sifariş etmək üçün create_order("SG21", user_context) çağırır. user_context sınaq üçün statik doldurula bilər (ad, telefon, ünvan və s.). Bu funksiyanın nəticəsi, məsələn, {"order_id": "ORD12345", "status": "SUCCESS"} olmalıdır. Konsolda göstərilir:  
[TEST] Sifariş yaratma: Məhsul ID: SG21, Müştəri: Test User Nəticə: Order ORD12345 yaradıldı, status SUCCESS Cavab JSON: {"reply": "Sifarişiniz uğurla yaradıldı. Sifariş nömrəsi: ORD12345."}   
Bu, sifariş prosesinin uçdan uca işlədiyini təsdiqləyəcək.  
  
API Açarlarının Sağlamlıq Yoxlaması (Health Check): Menyu 6 seçiləndə, sistem yuxarıda təsvir edilən açar yoxlama prosesini (startup-da olan) manual işə salar. Yəni:  
  
Groq API test sorğusu,  
  
OpenAI (əgər inteqrasiya olunubsa) test sorğusu,  
  
WhatsApp token test,  
  
Digər varsa onlar. Bütün nəticələr konsolda göstərilir (yaşıl OK, qırmızı ERROR və ya istisna mesajı). Bu, runtime zamanı da yoxlamağa yaraya bilər, məsələn, əgər şübhə varsa ki, gün ərzində bəlkə açarlardan biri etibarsızlaşıb.  
  
Bütöv Sistem Dialoq Testi: Bu əlavə seçimdir (menyu 7). Burada məqsəd bir nəfəsə bütün sistemi inteqrasiya test etməkdir. Məsələn, qabaqcadan ssenari hazırlana bilər:  
  
İstifadəçi: "Salam"  
  
Bot: (salamlaşma cavabı)  
  
İstifadəçi: (bir şəkil göndərir)  
  
Bot: (şəkilin caption+OCR strukturlaşdırılmış cavabı)  
  
İstifadəçi: "Bu məhsulu sifariş et"  
  
Bot: (sifariş yaratma prosesi və təsdiqi) Bu cür ssenarini avtomatlaşdırmaq bir qədər mürəkkəb olsa da, kiçik bir skriptlə mümkün ola bilər. Sistem bir-bir funksiyaları çağırıb ardıcıl cavabları yığa və sonunda bütün dialoqu konsola çap edə bilər. Bu, əlbəttə, advanced test kateqoriyasına girir.  
  
Test Menyusunun Implementasiyası: Bu menyunu yaratmaq üçün Python-da sadə bir script yazıla bilər (test_menu.py). İçində while True: loop ilə user input alıb yuxarıdakı işləri edən if/elif blokları olacaq. Bu skript birbaşa sistem modullarını idxal edib funksiyaları çağıracağı üçün, lazımi yerlərdə modul interfeyslərini bir az refaktor edib testə açmaq gərəkə bilər. Məsələn, groq_modules.py içindəki funksiyaları sadə dillə çağırıla bilən etməliyik (zaten elədir yəqin ki), bridge.py içindəki funksiya çağırışlarını modul funksiyası kimi də istifadə etmək üçün bəlkə bölməliyik (məs: handle_message(message) funksiyası yazıb, həm API route oradan istifadə etsin, həm də test scripti birbaşa ona müraciət etsin).  
Web interfeys variantı: Alternativ olaraq, Flask serverinə /test adında bir route əlavə edib, oradan parametrlə hansı testi işlədəcəyini göndərmək olar. Məsələn, GET /test?case=1 şəkil testini işə salar və brauzerə yuxarıdakı konsol çıxışı kimi məlumatları text olaraq göndərər. Bu, developer-ə uzaqdan (server erişimi yoxdursa belə) test etməyə imkan verə bilər. Lakin təhlükəsizlik baxımından bu route-u ya auth tələbli, ya da ancaq lokal host üçün açıq etmək lazımdır ki, hər kəs işlədə bilməsin.  
Avtomatik Testlər: Əlavə olaraq, bu test ssenarilərini avtomatlaşdırıb bir CI (Continuous Integration) mühitində də çalışdırmaq olar. Məsələn, PyTest yazaraq hər funksiyanı test etmək. Lakin hazırkı tələbdə interaktiv test istənilib. Gələcəkdə, test_menu scriptindəki funksionallığı PyTest ssenarilərinə də uyğunlaşdırmaq pis olmaz.  
Bu test menyusu sayəsində, sistemdə edilən dəyişikliklərin hər bir alt komponentə təsirini tez yoxlamaq mümkün olacaq. Xüsusən, funksiya çağırışı kimi mürəkkəb mexanizmlər əlavə edildikdən sonra, onları ayrı-ayrılıqda test edib debug etmək asanlaşacaq. Testlər zamanı aşkarlanan problem çıxarsa, müvafiq modulun loglarına baxılıb düzəlişlər ediləcək, sonra testlər təkrarlanacaq. Nəhayət, bütün testlər uğurlu olarsa, sistemin yeni versiyasını istehsalata (production) buraxmaq daha etibarlı olacaq.  
  
Nəticə və Ümumi Yekun  
  
Yuxarıda təqdim olunan təkliflər PierringShot Electronics™ multimodal AI backend sisteminin mövcud funksionallığını daha yüksək səviyyəyə qaldırmaq məqsədi daşıyır. Təkmilləşdirmələr mövcud imkanları məhv etmir, əksinə üzərinə yeni qatlar əlavə edir:  
  
Cavabların formatı daha strukturlaşdırılmış və informativ olacaq, bu da son istifadəçinin anlayışını asanlaşdıracaq.  
  
Süni intellektin function calling imkanı ilə inteqrasiyası sistemi daha ağıllı və adaptiv edəcək; yəni sistem statik qaydalardan dinamik qərarvermə mexanizminə keçid edəcək.  
  
Yeni API açarlarının dəstəklənməsi və çevik konfiqurasiya, sistemin uzunmüddətli baxımdan dayanıqlılığını artıracaq (açarların dəyişməsi və ya yeni servislərin əlavə olunması asanlaşacaq).  
  
Lokalizasiya edilmiş promptlar və təlimatlar sayəsində AI modelinin cavabları daha dəqiq, lokal və uyğun olacaq, eyni zamanda təhlükəsiz və nəzarətli şəkildə qalacaq.  
  
Test menyusu və avtomatlaşdırılmış yoxlamalar, inkişaf prosesində geri dönüt dövrünü sürətləndirəcək və sistemin istənilən dəyişiklikdən sonra stabil qalmasını təmin edəcək.  
  
Bütün bu dəyişikliklər mərhələli şəkildə implementasiya olunmalıdır. İlk öncə strukturlaşdırılmış cavablar və prompt lokalizasiyası kimi "asan" qisimlər hazırlanıb test edilə bilər. Daha sonra function calling inteqrasiyası kimi çətin mərhələyə keçilərək, orada da geniş testlər aparılmalıdır.  
Sonda, yenilənmiş sistem istehsalata verildikdə, istifadəçilər üçün xidmət keyfiyyətinin yüksəldiyi dərhal hiss olunacaq. Məsələn, əvvəl sadəcə bir cümləlik cavab alan istifadəçi, indi daha dolğun və anlaşılan cavab alacaq; kompleks sorğulara sistem daha uğurla cavab verəcək. Bu da PierringShot Electronics-in müştəri məmnuniyyətini artıracaq və innovativ texnologiya istifadəsini nümayiş etdirəcək.  
Qeyd: Bu sənədin .md formatında olması, istənilən platformada rahat oxunmasını təmin edir. Buradakı kod parçaları və JSON nümunələri implementasiya zamanı birbaşa istifadə oluna bilər. Hər hansı bug fix və ya əlavə tələb olarsa, bu sənəddəki bölmələrə uyğun şəkildə dəyişiklik etmək mümkün olacaq.  
Beləliklə, planlanan təkmilləşdirmələr ardıcıl tətbiq olunarsa, PierringShot Electronics™ multimodal AI sistemi daha güclü, etibarlı və ağıllı bir versiyaya yüksələcəkdir.

##TAPŞIRIĞIN!
"Buna bax qardaşım gör nələr uyğun de il görürsən sənə çox xahiş edirəm verdiyim bridge.py wwjs_listrner.js və əgər ehtiyac olarsa groq modulları olan python scriptini də həmçinin ehtiyac olan digər dəyişikliklərdə tam edilmiş formada yəni ki real deyərlər ilə tamamilə işlək sadəcə kopyalayıb yapışdıra biləcəyim təkmilləşdirilmiş yəni ki bütün tip medialdır dəstəkləyə bilən ardından əsasda məhsulları həm göndərə bilsin həm də ki qəbul edirsiniz doğru şəkildə ai modelinə göndərə bilsin. Əsas normal qaydada axış getməsin istəyirəm ki yəni məsələn məhsul axtarışı eliyəndə də və yaxud da yeni müraciəti məhsul sifarişinizade csv fayllarına yazmağı və yaxud o verilən csv-nin içindəki məhsulunun məlumatlarını məsələn qiyməti nəzərdə axtarış eləyən is soruşan müştəriyə təqdim edə bilsin bu formada istəyirəm sənə indi ehtiyac olan nəsə varsa verim kodla bağlı strukturla bağlı yoxdusa o zaman sənə zəhmət buyur ver mənə hər birinə ayır ayrıcalıqda kopyalaya biləcəyim formada.!"

