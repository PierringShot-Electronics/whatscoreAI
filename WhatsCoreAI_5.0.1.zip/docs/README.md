## Yeni Xüsusiyyətlər (v2.0)

### Real-time Notification Sistemi
- İstifadəçilərə avtomatik bildirişlər göndərmək
- Uğursuz cəhdlər üçün avtomatik retry mexanizmi
- Webhook dəstəyi ilə xarici sistemlərə inteqrasiya

### Dynamic Rate Limit İdarəetmə
- API istifadəsinə avtomatik nəzarət
- Yüksək yüklənmə zamanı avtomatik tənzimləmə
- Hər xidmət üçün fərqli limit konfiqurasiyası

### Automated Backup Sistemi
- Gündəlik avtomatik backup
- Manual backup yaratma imkanı
- Backupdan bərpa funksiyası
- Köhnə backup fayllarının avtomatik təmizlənməsi

### Performance Monitoring
- Real-time sistem metrikaları
- CPU, yaddaş, disk istifadəsinin monitorinqi
- Sağlamlıq yoxlamaları və xəbərdarlıqlar
- Tarixə görə performans statistikası

## Qurulum Əlavələri

### Əlavə Tələblər
```bash
pip install watchdog psutil pyyaml schedule
```

### Konfiqurasiya Əlavələri
`config/notifications.json` - Notification sistemi üçün webhook URL və digər parametrlər
```json
{
  "webhook_url": "https://example.com/notifications",
  "enabled": true,
  "retry_count": 3
}
```

`config/rate_limits.json` - API limitləri üçün konfiqurasiya
```json
{
  "limits": {
    "groq_api": {
      "requests_per_minute": 60,
      "tokens_per_minute": 6000
    }
  },
  "auto_adjust": true
}
```

## İstifadə Nümunələri

### Notification Göndərmə
```python
from core.notification_manager import NotificationManager
nm = NotificationManager()
nm.add_notification("order_update", "user123", "Sifarişiniz hazırlanır", {"order_id": 12345})
```

### Rate Limit Yoxlaması
```python
from core.rate_limit_manager import RateLimitManager
rlm = RateLimitManager()
if rlm.check_limit("groq_api", tokens_used=500):
    # API çağırışını et
else:
    # Gözlə
```

### Backup Yaratma
```python
from core.backup_manager import BackupManager
bm = BackupManager()
backup_result = bm.create_manual_backup()
```

### Performance Monitor
```python
from core.performance_monitor import PerformanceMonitor
pm = PerformanceMonitor()
pm.start_periodic_monitoring(interval=300)  # 5 dəqiqədə bir
health = pm.get_health_status()
```

## Yeniləmə Qaydası

1. Köhnə versiyanın backupını yaradın:
```bash
python3 -c "from core.backup_manager import BackupManager; print(BackupManager().create_manual_backup())"
```

2. Yeni faylları köçürün:
```bash
cp -r new_version/core/* existing_project/core/
cp -r new_version/config/* existing_project/config/
```

3. Yeni tələb olunan paketləri quraşdırın:
```bash
pip install -r requirements.txt
```

4. Sistemi yenidən başladın:
```bash
./run_wwjs.sh
```

## Bilinən Məhdudiyyətlər

- Notification sistemi yalnız vebhook ünvanı düzgün qurulduqda işləyir
- Rate limit avtomatik tənzimləmə yüksək yüklənmə zamanı API cavablarını ləngidə bilər
- Backup sistemi böyük fayllar üçün çox yaddaş istifadə edə bilər


# PierringShot Electronics™ WhatsApp AI Assistant - Tam Yenilənmiş Fayl Sistemi

## Əsas Fayl Strukturu

```
whatscore.ai/
├── core/                     # Əsas sistem modulları
│   ├── __init__.py
│   ├── admin_panel.py        # Admin paneli idarəetmə modulu
│   ├── backup_manager.py     # Backup idarəetmə sistemi
│   ├── bridge.py             # Əsas Flask API serveri
│   ├── config_loader.py      # Konfiqurasiya yükləyici
│   ├── csv_search.py         # CSV məlumat bazası axtarışı
│   ├── delivery_manager.py   # Çatdırılma idarəetməsi
│   ├── e_commerce.py         # E-ticarət funksiyaları
│   ├── groq_modules.py       # Groq API inteqrasiyası
│   ├── label_manager.py      # Etiket idarəetmə sistemi
│   ├── live_agent_handler.py # Canlı agentə yönləndirmə
│   ├── memento_integration.py # Memento DB inteqrasiyası
│   ├── notification_manager.py # Bildiriş idarəetməsi
│   ├── performance_monitor.py # Performans monitorinqi
│   ├── personalization.py    # İstifadəçi fərdiləşdirmə
│   ├── prompt_selector.py    # Prompt seçimi
│   ├── rate_limit_manager.py # Sorğu limitləri
│   ├── report_builder.py     # Hesabat generatoru
│   └── submodules/           # Əlavə modullar
├── csv_data/                 # Məlumat bazası faylları
│   ├── products.csv          # Məhsul siyahısı
│   ├── orders.csv            # Sifarişlər
│   └── customers.csv         # Müştəri məlumatları
├── docs/                     # Sənədlər
│   ├── deep_research.txt     # Dərin araşdırma məlumatları
│   └── API_blueprint.apib    # API spesifikasiyası
├── media/                    # Media faylları
│   ├── audio/                # Audio mesajlar
│   ├── image/                # Şəkillər
│   └── video/                # Videolar
├── node_modules/             # Node.js paketləri
├── user_contexts/            # İstifadəçi dialoq kontekstləri
│   ├── user_123456789.json   # İstifadəçi kontekst faylı
│   └── user_987654321.json
├── venv/                     # Python virtual mühiti
├── .env                      # Konfiqurasiya dəyişənləri
├── package.json              # Node.js paket konfiqurasiyası
├── requirements.txt          # Python tələbləri
├── run_wwjs.sh               # İşə salma skripti
└── wwebjs_listener.js        # WhatsApp WebJS dinləyicisi
```

## Əsas Fayl Məzmunları

### 1. core/bridge.py (Yenilənmiş Flask API)

```python
from flask import Flask, request, jsonify
from dotenv import load_dotenv
from groq import Groq
import os
import json
import logging
from core.groq_modules import groq_caption, groq_transcribe
from core.csv_search import search_products
from core.e_commerce import create_order
from core.personalization import get_user_context, save_user_context
from waitress import serve

# Konfiqurasiya yüklənməsi
load_dotenv()
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

# Logging konfiqurasiyası
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('core/logs/bridge.log'),
        logging.StreamHandler()
    ]
)

def get_groq_client():
    """Groq API client-inin yaradılması"""
    return Groq(api_key=os.getenv("GROQ_API_KEY"))

@app.route("/api/process", methods=["POST"])
def process_handler():
    """İstifadəçi mesajlarının emalı"""
    try:
        data = request.json or {}
        msg_type = data.get("type", "chat")
        user_id = data.get("from", "unknown")
        content = data.get("content", "").strip()
        
        # Media növünə görə emal
        if msg_type == "image":
            return handle_image(data, user_id)
        elif msg_type == "audio":
            return handle_audio(data, user_id)
        elif msg_type == "location":
            return handle_location(data, user_id)
        else:
            return handle_text(data, user_id)
    
    except Exception as e:
        logging.error(f"Process error: {str(e)}")
        return jsonify({"reply": "Xəta baş verdi, zəhmət olmasa yenidən cəhd edin"})

def handle_image(data, user_id):
    """Şəkil mesajlarının emalı"""
    file_path = data.get("filePath", "")
    if not os.path.exists(file_path):
        return jsonify({"error": "Şəkil faylı tapılmadı"}), 404
    
    # Şəkil analizi
    caption = groq_caption(file_path)
    reply = f"📷 Şəkil təsviri: {caption}\n"
    
    # Kontekstə əlavə et
    context = get_user_context(user_id)
    context.append({"role": "assistant", "content": reply})
    save_user_context(user_id, context)
    
    return jsonify({"reply": reply})

# Digər handler funksiyaları...
# (audio, location, text üçün oxşar funksiyalar)

if __name__ == "__main__":
    serve(app, host="0.0.0.0", port=int(os.getenv("PORT", 9876)))
```

### 2. core/groq_modules.py (Yenilənmiş)

```python
import os
import io
import base64
import tempfile
import subprocess
import wave
import logging
from PIL import Image
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO)

def groq_caption(image_path):
    """Şəkil üçün təsvir generasiyası"""
    try:
        client = Groq(api_key=os.getenv("GROQ_API_KEY"))
        
        with open(image_path, "rb") as img_file:
            img_data = base64.b64encode(img_file.read()).decode('utf-8')
        
        response = client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[
                {"role": "system", "content": "Şəkili dəqiq təsvir et, Azərbaycan dilində"},
                {"role": "user", "content": [
                    {"type": "image_url", "image_url": f"data:image/jpeg;base64,{img_data}"}
                ]}
            ],
            max_tokens=300
        )
        
        return response.choices[0].message.content
    
    except Exception as e:
        logging.error(f"Şəkil analiz xətası: {str(e)}")
        return "Şəkil analiz edilərkən xəta baş verdi"

def groq_transcribe(audio_path):
    """Audio transkripsiyası"""
    try:
        client = Groq(api_key=os.getenv("GROQ_API_KEY"))
        
        # Audio formatını çevir
        wav_path = convert_to_wav(audio_path)
        
        with open(wav_path, "rb") as audio_file:
            transcription = client.audio.transcriptions.create(
                file=audio_file,
                model="whisper-large-v3",
                language="az"
            )
        
        return transcription.text
    
    except Exception as e:
        logging.error(f"Audio transkript xətası: {str(e)}")
        return "Audio transkript edilərkən xəta baş verdi"
    finally:
        if os.path.exists(wav_path):
            os.remove(wav_path)

def convert_to_wav(input_path):
    """Audio faylını WAV formatına çevir"""
    output_path = tempfile.mktemp(suffix=".wav")
    subprocess.run([
        "ffmpeg", "-i", input_path,
        "-acodec", "pcm_s16le",
        "-ar", "16000",
        "-ac", "1",
        "-y", output_path
    ], check=True)
    return output_path
```

### 3. wwebjs_listener.js (Yenilənmiş)

```javascript
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: { headless: true }
});

// Media qovluqlarının yaradılması
const MEDIA_DIR = path.join(__dirname, 'media');
['audio', 'image', 'video'].forEach(dir => {
    if (!fs.existsSync(path.join(MEDIA_DIR, dir))) {
        fs.mkdirSync(path.join(MEDIA_DIR, dir), { recursive: true });
    }
});

client.on('qr', qr => qrcode.generate(qr, { small: true }));

client.on('ready', () => console.log('WhatsApp AI Assistant hazırdır!'));

client.on('message', async msg => {
    try {
        // Status mesajlarını ignore et
        if (msg.from.includes('status@broadcast')) return;
        
        console.log(`Yeni mesaj: ${msg.type} | Göndərən: ${msg.from}`);
        
        let response;
        switch (msg.type) {
            case 'image':
                response = await handleImage(msg);
                break;
            case 'audio':
                response = await handleAudio(msg);
                break;
            default:
                response = await handleText(msg);
        }
        
        if (response) {
            await msg.reply(response.reply);
        }
    } catch (error) {
        console.error('Xəta:', error);
        msg.reply('Xəta baş verdi, yenidən cəhd edin');
    }
});

async function handleImage(msg) {
    const media = await msg.downloadMedia();
    const imagePath = path.join(MEDIA_DIR, 'image', `${Date.now()}.jpg`);
    fs.writeFileSync(imagePath, media.data, 'base64');
    
    const apiResponse = await axios.post('http://localhost:9876/api/process', {
        type: 'image',
        from: msg.from,
        filePath: imagePath
    });
    
    return apiResponse.data;
}

// Digər handler funksiyaları...

client.initialize();
```

### 4. csv_data/products.csv (Nümunə məlumatlar)

```csv
product_id,name,description,price,stock,category,brand
1001,Laptop Pro 15,"15.6'' FHD, Intel i7, 16GB RAM, 512GB SSD",1899.99,12,Computers,Dell
1002,Smartphone X,"6.5'' AMOLED, 128GB, 48MP Camera",899.50,25,Phones,Samsung
1003,Wireless Earbuds,"Noise cancelling, 20h battery",149.99,34,Audio,Sony
1004,Gaming Mouse,"RGB, 8000DPI, 6 buttons",59.90,18,Accessories,Logitech
1005,4K Monitor,"27'', IPS, HDR, 144Hz",499.00,8,Monitors,ASUS
```

### 5. .env (Nümunə konfiqurasiya)

```ini
GROQ_API_KEY=gsk_abc123xyz456
WHATSAPP_TOKEN=abc123
PORT=9876
CSV_PATH=./csv_data/products.csv

# Servis ünvanları
SERVICE_LOCATIONS={
    "depo": {
        "name": "Əsas Depo",
        "address": "Həsən Əliyev 96, Bakı",
        "url": "https://maps.google.com/?q=40.3777,49.8920"
    },
    "servis": {
        "name": "Texniki Servis Mərkəzi",
        "address": "S.Rüstəm 15d, Bakı",
        "url": "https://maps.google.com/?q=40.3755,49.8901"
    }
}
```

### 6. requirements.txt

```
flask==2.3.2
python-dotenv==1.0.0
groq==0.3.0
waitress==2.1.2
pillow==10.0.0
pandas==2.0.3
sentence-transformers==2.2.2
```

### 7. run_wwjs.sh (İşə salma skripti)

```bash
#!/bin/bash

# Köhnə prosesləri dayandır
pkill -f "bridge.py"
pkill -f "wwebjs_listener.js"

# Log qovluğunu təmizlə
rm -rf core/logs/*
mkdir -p core/logs

# Python virtual mühitini aktiv et
source venv/bin/activate

# Bridge servisini başlat
nohup python -u core/bridge.py > core/logs/bridge.log 2>&1 &

# Node.js servisini başlat
nohup node wwebjs_listener.js > core/logs/listener.log 2>&1 &

echo "Sistem uğurla işə salındı!"
echo "Bridge log: tail -f core/logs/bridge.log"
echo "Listener log: tail -f core/logs/listener.log"
```

## Ətraflı İzahat

1. **core/bridge.py** - Sistemin əsas API endpoint-lərini təmin edir. İstifadəçi mesajlarını qəbul edir, müvafiq emal funksiyalarını çağırır və cavab qaytarır.

2. **core/groq_modules.py** - Groq API ilə inteqrasiyanı idarə edir. Şəkil təsviri generasiyası və audio transkripsiyası funksiyalarını ehtiva edir.

3. **wwebjs_listener.js** - WhatsApp WebJS inteqrasiyasını həyata keçirir. İstifadəçi mesajlarını dinləyir və bridge API-ə yönləndirir.

4. **csv_data/products.csv** - Məhsul məlumat bazası. Bütün məhsulların siyahısı, qiymətləri və stok vəziyyəti burada saxlanılır.

5. **.env** - Bütün həssas konfiqurasiya dəyişənləri. API açarları, port nömrələri və servis ünvanları burada təyin olunur.

6. **requirements.txt** - Python tələb olunan paketlərin siyahısı.

7. **run_wwjs.sh** - Bütün sistemi işə salmaq üçün bash skripti. Həm Python bridge, həm də Node.js listener servislərini başladır.

Bu yenilənmiş struktura ilə PierringShot Electronics™ WhatsApp AI Assistant daha stabil, təhlükəsiz və genişlənə bilən şəkildə işləyəcək. Bütün komponentlər bir-biri ilə yaxşı inteqrasiya olunub və real dəyərlərlə işləyir.