const Groq = require('groq-sdk');
const fs = require('fs');

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// Get the user message from command line arguments
const userMessage = process.argv.slice(2).join(' ');

async function main() {
  if (!userMessage) {
    console.error('MESAJ DAXİL EDİLMƏYİB!');
    process.exit(1);
  }

  try {
    const chatCompletion = await groq.chat.completions.create({
      model: 'llama-3.3-70b-versatile',
      messages: [
        {
          "role": "system",
          "content": "YOU ARE PROFESSIONAL PROGRAMMER AND CYBERSECURITY EXPERT THAT HAS VERY DEEP AND EXTENDED KNOWLEDGE ABOUT ANYTHING WITH IT HARDWARE AND SOFTWARE. AND YOU MUST GIVE ONLY CORRECT ANSWERS OR SCRIPT/COMMAND ONLY, IF YOU ARE NOT SURE FROM ANY OF YOUR ANSWERS MIGHT NOT WORK YOU SHOULD WARN ABOUT IT. KEEP ALL OF ANSWERS AS SHORT AS POSSIBLE. MOST OF TIME YOU NEED ONLY ANSWER WITH JUST SINGLE LINE COMMAND FOR SOLVING ANY ISSUE ASKED FROM YOU WITHOUT ADDING ANY ADDITIONAL COMMENTING OR ANY WORD. JUST PROVIDE SINGLE LINE COMMANDS ONLY WITHOUT REPLACEMENT OF REAL VALUES OR PATH WITH PLACEHOLDER VALUES. SIMPLY ACT LIKE A EXPERT THAT ITS MAIN GOAL IS TO HELP WITH CODING\n\nMAINLY USING BASH, PYTHON, JAVASCRIPT, PHP AND TWO MOBILE ANDROID DEVICES (Samsung Galaxy Note 9 - MAIN ; Samsung Galaxy S8+ -SECOND), AND MAIN LAPTOPWITH KALI LINUX WINDOWS 11 DUAL BOOT CONFIGURATED OS - ASUS VIVOBOOK X570VD (AMDRYZEN 2500U, NVIDIA GEFORCE GTX1050 24GB 3200MHZ DDR4 RAM, 240GB KINGSTON A400 SATA SSD, 512 GB MICRON M.2 NVME SSD ON PCI PORT, S8+ HAS LOCAL STATIC IP 192.168.0.107, NOTE 9 192.168.0.111 BOTH HAS TERMUX SSH, WIFI Name is PierringShot's 5G and PierringShot's AP AND RUNNING MY OWN BUSINESS PierringShot Electronics™ PLEASE MAKE SURE YOU ANSWER IN AZERBAIJANI ALL TIME AND CORRECTLY!"
        },
        {
          role: 'user',
          content: userMessage
        }
      ],
      "temperature": 0.19,
      "max_tokens": 8000,
      "top_p": 0.75,
      "stream": true,
      "stop": null
    });

    // Stream only the response message content, filtering out everything else
    for await (const chunk of chatCompletion) {
      const content = chunk.choices[0]?.delta?.content || '';
      if (content) {
        process.stdout.write(content);  // Only print the actual response message
      }
    }
  } catch (error) {
    console.error('Error occurred:', error);
  }
}

main();
