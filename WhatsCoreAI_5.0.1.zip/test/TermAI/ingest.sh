#!/bin/bash

# PierringShot Electronics™ tərəfindən təkmilləşdirilib!

# --- Configuration ---
# Scripting file extensions (full content)
SCRIPT_EXTS=("js" "ts" "sh" "py" "php" "bash" "java" "swift" "c" "cjs" "mjs")

# Secondary important file extensions (full or partial content)
SECONDARY_EXTS=("txt" "csv" "json" "yaml" "yml" "md" "conf" "log" ".env" "html" "css")

# File types for head/tail (partial content)
PARTIAL_CONTENT_EXTS=("txt" "csv" "json" "log")
HEAD_PERCENT=0.05 # 5%
TAIL_PERCENT=0.10 # 10%

# File types to exclude from content change percentage calculation (semantic versioning)
EXCLUDE_FROM_DIFF_CALC=("log" "json" "csv" "txt" "mp3" "ogg" "mp4" "jpg" "jpeg" "png" "gif" "svg" "webp" "ico")

# Directories/files to exclude from content processing and tree
EXCLUDE_PATHS=("node_modules" "venv" "__pycache__" "tmp" ".git" ".vscode" ".cache" ".debug" "*cache*" "package-lock.json" ".gitignore")

# Tree depth for structure
TREE_DEPTH=3 

# Safety thresholds for large projects (for initial confirmation)
LARGE_PROJECT_FILE_THRESHOLD=500
LARGE_PROJECT_DIR_THRESHOLD=50
CONFIRMATION_MARKER_FILE=".ingest_confirmed" # Marker for per-directory confirmation

# SSH Transfer Configuration
# BURADA ÖZ SSH MƏLUMATLARINIZI DAXİL EDİN!
SSH_USER_HOST="pierring@192.168.0.111" # Your SSH user and host (e.g., user@your_server_ip)
SSH_REMOTE_BASE_PATH="/storage/emulated/0/ingested" # Base path on remote server (e.g., /path/to/ingested_data)


# --- Utility Functions ---

# Function to escape special characters for Markdown code blocks
escape_for_markdown() {
    # Replace backticks with a placeholder and then restore them
    sed 's/```/\\`\\`\\`/g'
}

# Function to calculate overall content difference percentage (excluding specified file types)
calculate_overall_diff_percentage() {
    local file1_path="$1" # Path to the last ingest markdown file
    local file2_path="$2" # Path to the current generated temp markdown file

    if [ ! -f "$file1_path" ] || [ ! -f "$file2_path" ]; then
        echo "100" # If previous file doesn't exist, consider it 100% new
        return
    fi 

    # Create temp files for filtered content from markdown
    local temp_filtered_content1=$(mktemp)
    local temp_filtered_content2=$(mktemp)

    # Awk script for filtering content for diff calculation
    local awk_script='
        BEGIN {
            FS="#### =======================";
            split(ENVIRON["EXCL_EXTS_STR"], exclude_array, " ");
            for (i in exclude_array) exclude_map[exclude_array[i]] = 1;
            in_file_block = 0;
            collect_content = 0;
            current_file_path = "";
            skip_ai_intro = 0;
        }
        $0 ~ /^## AI Model üçün Təlimat/ { skip_ai_intro = 1; next; }
        skip_ai_intro == 1 && $0 == "" { skip_ai_intro = 0; next; }
        skip_ai_intro == 1 { next; }

        $0 ~ /^#### ======================= \*\*.*\*\* ==========================/ {
            in_file_block = 1;
            current_file_path = $0;
            sub(/#### ======================= \*\*/, "", current_file_path);
            sub(/\*\* ==========================/, "", current_file_path);
            
            collect_content = 1;
            file_extension = current_file_path;
            sub(/.*\./, "", file_extension);
            
            if (current_file_path == ".env" || current_file_path == ".env.example") {
                collect_content = 1; # Always include .env for diff
            } else {
                for (ext in exclude_map) {
                    if (file_extension == ext) {
                        collect_content = 0;
                        break;
                    }
                }
            }
            next;
        }
        $0 ~ /^```/ {
            if (in_file_block == 1) {
                # Skip markdown block delimiters
            }
            next;
        }
        in_file_block == 1 {
            if (collect_content == 1) {
                if ($0 !~ /^\.\.\.$/ && $0 !~ /^\(Məzmun kəsildi - fayl böyükdür\)/) {
                    print $0;
                }
            }
        }
    '

    # Pass EXCLUDE_FROM_DIFF_CALC as environment variable to awk
    EXCL_EXTS_STR="${EXCLUDE_FROM_DIFF_CALC[*]}" awk "${awk_script}" "$file1_path" > "$temp_filtered_content1"
    EXCL_EXTS_STR="${EXCLUDE_FROM_DIFF_CALC[*]}" awk "${awk_script}" "$file2_path" > "$temp_filtered_content2"


    # Calculate diff
    local total_lines1=$(wc -l < "$temp_filtered_content1")
    local total_lines2=$(wc -l < "$temp_filtered_content2")

    if (( total_lines1 == 0 && total_lines2 == 0 )); then
        echo "0"
        rm "$temp_filtered_content1" "$temp_filtered_content2"
        return
    fi

    local diff_output=$(diff -w -B "$temp_filtered_content1" "$temp_filtered_content2")
    local added_lines=$(echo "$diff_output" | grep -c '^+[^ +-]*')
    local deleted_lines=$(echo "$diff_output" | grep -c '^-')
    local changed_lines=$((added_lines + deleted_lines))

    local max_lines=$(( total_lines1 > total_lines2 ? total_lines1 : total_lines2 ))

    local diff_percentage=0
    if (( max_lines > 0 )); then
        # Use bc for floating point arithmetic, then printf for rounding
        diff_percentage=$(echo "scale=2; ($changed_lines / $max_lines) * 100" | bc)
    fi
    
    printf "%.0f\n" "$diff_percentage" # Round to nearest integer

    rm "$temp_filtered_content1" "$temp_filtered_content2"
}

# Function to determine semantic version increment
get_semantic_version() {
    local diff_percentage="$1" 
    local current_version="$2"
    local major minor patch
    IFS='.' read -r major minor patch <<< "$current_version"

    if (( $(echo "$diff_percentage <= 29" | bc -l) )); then
        ((patch++))
    elif (( $(echo "$diff_percentage <= 35" | bc -l) )); then
        patch=2 # 0.0.2
    elif (( $(echo "$diff_percentage <= 40" | bc -l) )); then
        patch=4 # 0.0.4
    elif (( $(echo "$diff_percentage <= 60" | bc -l) )); then
        patch=6 # 0.0.6
    else # > 60% change, consider it a minor version increment
        patch=0
        ((minor++))
    fi

    # Handle overflow (e.g., 0.0.10 becomes 0.1.0)
    if (( patch >= 10 )); then
        patch=0
        ((minor++))
    fi 
    if (( minor >= 10 )); then
        minor=0
        ((major++))
    fi

    printf "%d.%d.%d\n" "$major" "$minor" "$patch"
}

# --- Progress Bar Function ---
# $1: current, $2: total, $3: message
progress_bar() {
    local current=$1
    local total=$2
    local message="$3"
    local progress=$(( (current * 100) / total ))
    local bar_len=$(( progress / 2 )) # Scale to 50 chars
    local empty_len=$(( 50 - bar_len ))

    local bar_fill=$(printf "#%.0s" $(seq 1 $bar_len))
    local bar_empty=$(printf ".%.0s" $(seq 1 $empty_len))

    # Color definitions (ANSI escape codes)
    local GREEN='\033[0;32m'
    local YELLOW='\033[1;33m'
    local CYAN='\033[0;36m'
    local NC='\033[0m' # No Color
    local RED='\033[0;31m'

    # Estimate Time of Arrival (ETA) - very basic, can be improved
    local elapsed_time=$(( SECONDS - START_TIME ))
    local eta="Hesablanır..."
    if (( current > 0 && elapsed_time > 0 )); then
        local time_per_item=$(echo "scale=2; $elapsed_time / $current" | bc)
        local remaining_items=$(( total - current ))
        local remaining_time=$(echo "scale=0; $remaining_items * $time_per_item" | bc)
        
        # Convert remaining_time to HH:MM:SS format
        local hours=$(( remaining_time / 3600 ))
        local minutes=$(( (remaining_time % 3600) / 60 ))
        local seconds=$(( remaining_time % 60 ))
        eta=$(printf "%02d:%02d:%02d" $hours $minutes $seconds)
    fi

    echo -ne "${CYAN}[${bar_fill}${bar_empty}] ${progress}% ${message} - ETA: ${eta}${NC}\r"
}


# --- Main Ingest Logic ---

# Record start time for ETA calculation
START_TIME=$SECONDS

# Display "PierringShot Electronics™ təkmilləşdirib!" message
echo -e "\n${CYAN}===============================================${NC}"
echo -e "${CYAN}  PierringShot Electronics™ tərəfindən təkmilləşdirilib!  ${NC}"
echo -e "${CYAN}===============================================${NC}\n"

CURRENT_DIR_PATH="$(pwd)"
CURRENT_DIR_NAME=$(basename "$CURRENT_DIR_PATH")
INGEST_DEBUG_DIR=".debug"
INGEST_HISTORY_DIR="$INGEST_DEBUG_DIR/history"
CHANGELOG_FILE="$INGEST_DEBUG_DIR/changelog.txt"
CONFIRMATION_MARKER_PATH="$INGEST_DEBUG_DIR/$CONFIRMATION_MARKER_FILE"

# Security check: Prevent running in sensitive directories
# 1. Prevent running in the root /home directory itself.
# 2. Prevent running directly inside any .debug directory (including its sub-directories).
if [[ "$CURRENT_DIR_PATH" == "/home" ]]; then
    echo -e "${RED}❌ Xəta: Bu skripti kök '/home' qovluğunda işə salmaq təhlükəsiz deyil.${NC}"
    exit 1
fi

if [[ "$CURRENT_DIR_PATH" == *"/.debug"* ]]; then
    echo -e "${RED}❌ Xəta: Bu skripti '.debug' qovluğunun içində və ya onun alt qovluqlarında işə salmaq təhlükəsiz deyil.${NC}"
    exit 1
fi

# Create .debug directory if it doesn't exist
mkdir -p "$INGEST_DEBUG_DIR"
mkdir -p "$INGEST_HISTORY_DIR"

# Initial large project confirmation
if [ ! -f "$CONFIRMATION_MARKER_PATH" ]; then
    echo -e "${YELLOW}Layihənin ölçüsü yoxlanılır...${NC}"
    NUM_FILES=$(find . -type f \( ! -path "*/${INGEST_DEBUG_DIR}/*" -a ! -name ".*" \) | wc -l)
    NUM_DIRS=$(find . -type d \( ! -path "*/${INGEST_DEBUG_DIR}/*" -a ! -name ".*" \) | wc -l)

    if (( NUM_FILES > LARGE_PROJECT_FILE_THRESHOLD || NUM_DIRS > LARGE_PROJECT_DIR_THRESHOLD )); then
        echo -e "${YELLOW}Bu layihə ${NUM_FILES} fayl və ${NUM_DIRS} qovluqdan ibarətdir. Bu, böyük bir layihə ola bilər və ingest prosesi uzun çəkə bilər.${NC}"
        read -p "$(echo -e "${YELLOW}Davam etmək istəyirsinizmi? (bəli/xeyr): ${NC}")" confirm_large_project
        if [[ "$confirm_large_project" != "bəli" && "$confirm_large_project" != "y" ]]; then
            echo -e "${RED}İşlem ləğv edildi.${NC}"
            exit 0
        else
            touch "$CONFIRMATION_MARKER_PATH" # Create marker file to avoid asking again
            echo -e "${GREEN}Təsdiqləndi. Davam edilir...${NC}"
        fi
    else
        touch "$CONFIRMATION_MARKER_PATH" # Create marker file even for small projects to skip future checks
    fi
fi

# Determine total files for progress bar
# This find command should accurately list all files whose content needs to be ingested.
ALL_FILES_FOR_PROGRESS_RAW=$(find . -type f \
    ! -path "*/${INGEST_DEBUG_DIR}/*" \
    ! -path "*/.git/*" \
    ! -path "*/node_modules/*" \
    ! -path "*/venv/*" \
    ! -path "*/__pycache__/*" \
    ! -path "*/tmp/*" \
    ! -path "*/.vscode/*" \
    ! -path "*/.cache/*" \
    ! -path "*/backups/*" \
    ! -path "*/.wwebjs_auth/*" \
    ! -path "*/.wwebjs_cache/*" \
    ! -name ".gitignore" \
    ! -name "package-lock.json" \
    ! -name ".*cache*" \
    -a \( -name ".*" -o -false \) \
)

# Filter ALL_FILES_FOR_PROGRESS_RAW to get only relevant files for content processing
ALL_FILES_TO_PROCESS_CONTENT=()
while IFS= read -r file; do
    filename=$(basename "$file")
    extension="${filename##*.}" # Extract extension
    
    is_scripting_file=0
    for ext in "${SCRIPT_EXTS[@]}"; do
        if [[ "$extension" == "$ext" ]]; then
            is_scripting_file=1
            break
        fi
    done

    is_secondary_file=0
    for ext in "${SECONDARY_EXTS[@]}"; do
        if [[ "$extension" == "$ext" || "$filename" == "$ext" ]]; then # For .env (no extension)
            is_secondary_file=1
            break
        fi
    done

    # Include if it's a scripting or secondary file, or explicitly .env/.env.example
    if [[ "$is_scripting_file" -eq 1 || "$is_secondary_file" -eq 1 || "$filename" == ".env" || "$filename" == ".env.example" ]]; then
        ALL_FILES_TO_PROCESS_CONTENT+=("$file")
    fi
done < <(echo "$ALL_FILES_FOR_PROGRESS_RAW")

TOTAL_FILES=${#ALL_FILES_TO_PROCESS_CONTENT[@]}
PROCESSED_FILES=0


# Start background process
(
    # Find the last ingest file
    LAST_INGEST_FILE=$(find "$INGEST_DEBUG_DIR" -maxdepth 1 -type f -name "${CURRENT_DIR_NAME}_*.md" | sort -V | tail -n 1)

    CURRENT_VERSION="0.0.0"
    if [ -f "$LAST_INGEST_FILE" ]; then
        VERSION_FROM_FILE=$(echo "$LAST_INGEST_FILE" | grep -o -E "${CURRENT_DIR_NAME}_([0-9]+\.[0-9]+\.[0-9]+)\.md" | grep -o -E "([0-9]+\.[0-9]+\.[0-9]+)")
        if [ -n "$VERSION_FROM_FILE" ]; then
            CURRENT_VERSION="$VERSION_FROM_FILE"
        fi
    fi

    # Generate the full content of the current state into a temporary file
    TEMP_CURRENT_CONTENT_FILE=$(mktemp)
    echo -e "# ${CURRENT_DIR_NAME}\n" > "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "---" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "**Ingest Vaxtı:** $(date '+%Y-%m-%d %H:%M:%S')" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "**Ingest Versiyası:** [TO_BE_SET]" >> "$TEMP_CURRENT_CONTENT_FILE" # Placeholder for version
    echo -e "---" >> "$TEMP_CURRENT_CONTENT_FILE"

    # AI Model Introduction
    echo -e "## AI Model üçün Təlimat\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "Sizə təqdim olunan bu fayl, mövcud layihənin bütün strukturunu və kod məzmununu əhatə edir. Məqsəd, AI modelinin layihəni tam olaraq anlayaraq sualları cavablandırması, dəyişikliklər təklif etməsi və ya yeni funksionallıqlar yaratması üçün zəruri məlumatı verməkdir. Faylın məzmunu strukturlaşdırılmış şəkildə təqdim olunur:\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "- **Fayl Məzmunları:** Əsas skript və digər vacib faylların məzmunları (böyük fayllar üçün kəsik şəkildə) təqdim olunur.\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "- **Qovluq Strukturu:** Layihənin ağacvari strukturu, fayl icazələri, sahibləri, ölçüləri və dəyişmə tarixləri daxil olmaqla göstərilir.\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "- **Terminal Keçmişi:** Son icra edilmiş əmrlər və terminal çıxışları daxildir.\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "Bu məlumat, AI-nin layihəni dərindən təhlil edərək daha dəqiq və effektiv nəticələr verməsinə imkan yaradır.\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "\n" >> "$TEMP_CURRENT_CONTENT_FILE"


    # 1. Readme File
    local readme_processed_for_content=0
    if [ -f "README.md" ]; then
        echo -e "#### ======================= **README.md** ==========================\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
        cat "README.md" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
        echo -e "\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
        readme_processed_for_content=1
        ((PROCESSED_FILES++))
        progress_bar $PROCESSED_FILES $TOTAL_FILES "README faylı işlənir..."
    elif [ -f "README" ]; then
        echo -e "#### ======================= **README** ==========================\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
        cat "README" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
        echo -e "\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
        readme_processed_for_content=1
        ((PROCESSED_FILES++))
        progress_bar $PROCESSED_FILES $TOTAL_FILES "README faylı işlənir..."
    fi

    local SCRIPTING_FILES_TO_PROCESS=()
    local SECONDARY_FILES_TO_PROCESS=()

    # Categorize files into scripting and secondary arrays
    for file in "${ALL_FILES_TO_PROCESS_CONTENT[@]}"; do
        filename=$(basename "$file")
        extension="${filename##*.}"
        
        # Skip README if it was already processed
        if [[ ("$filename" == "README.md" || "$filename" == "README") && "$readme_processed_for_content" -eq 1 ]]; then
            continue
        fi

        is_scripting_file=0
        for ext in "${SCRIPT_EXTS[@]}"; do
            if [[ "$extension" == "$ext" ]]; then
                is_scripting_file=1
                break
            fi
        done

        is_secondary_file=0
        for ext in "${SECONDARY_EXTS[@]}"; do
            if [[ "$extension" == "$ext" || "$filename" == "$ext" ]]; then
                is_secondary_file=1
                break
            fi
        done

        if [[ "$is_scripting_file" -eq 1 ]]; then
            SCRIPTING_FILES_TO_PROCESS+=("$file")
        elif [[ "$is_secondary_file" -eq 1 ]]; then
            SECONDARY_FILES_TO_PROCESS+=("$file")
        fi
    done

    # 2. Scripting Files (Full Content)
    if (( ${#SCRIPTING_FILES_TO_PROCESS[@]} > 0 )); then
        echo -e "\n## Scripting Files\n" >> "$TEMP_CURRENT_CONTENT_FILE"
        for file in "${SCRIPTING_FILES_TO_PROCESS[@]}"; do
            file_path="${file#./}"
            echo -e "#### ======================= **$file_path** ==========================\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
            cat "$file" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
            echo -e "\n\`\`\`\n\n" >> "$TEMP_CURRENT_CONTENT_FILE"
            ((PROCESSED_FILES++))
            progress_bar $PROCESSED_FILES $TOTAL_FILES "Skript faylları işlənir: ${file_path}"
        done
    fi

    # 3. Other Important Files (Full or Partial Content)
    if (( ${#SECONDARY_FILES_TO_PROCESS[@]} > 0 )); then
        echo -e "\n## Other Important Files\n" >> "$TEMP_CURRENT_CONTENT_FILE"
        for file in "${SECONDARY_FILES_TO_PROCESS[@]}"; do
            filename=$(basename "$file")
            file_path="${file#./}"

            echo -e "#### ======================= **$file_path** ==========================\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
            
            if [[ "$filename" == ".env" || "$filename" == ".env.example" ]]; then
                cat "$file" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
            else
                extension="${filename##*.}"
                is_partial_content=0
                for ext in "${PARTIAL_CONTENT_EXTS[@]}"; do
                    if [[ "$extension" == "$ext" ]]; then
                        is_partial_content=1
                        break
                    fi
                done

                if [[ "$is_partial_content" -eq 1 ]]; then
                    total_lines=$(wc -l < "$file")
                    head_lines=$(awk "BEGIN {print int($total_lines * $HEAD_PERCENT)}")
                    tail_lines=$(awk "BEGIN {print int($total_lines * $TAIL_PERCENT)}")

                    if (( head_lines + tail_lines < total_lines )); then
                        head -n "$head_lines" "$file" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
                        echo -e "\n...\n(Məzmun kəsildi - fayl böyükdür)\n...\n" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
                        tail -n "$tail_lines" "$file" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
                    else
                        cat "$file" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
                    fi
                else
                    cat "$file" | escape_for_markdown >> "$TEMP_CURRENT_CONTENT_FILE"
                fi
            fi
            echo -e "\n\`\`\`\n\n" >> "$TEMP_CURRENT_CONTENT_FILE"
            ((PROCESSED_FILES++))
            progress_bar $PROCESSED_FILES $TOTAL_FILES "İkinci dərəcəli fayllar işlənir: ${file_path}"
        done
    fi

    # 4. Directory Structure and File Details
    echo -e "\n## Directory Structure and File Details\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"

    TREE_EXCLUDE_ARGS=""
    for pattern in "${EXCLUDE_PATHS[@]}"; do
        if [[ "$pattern" != ".env" && "$pattern" != ".env.example" && "$pattern" != ".debug" ]]; then
            TREE_EXCLUDE_ARGS+=" -I '$pattern' "
        fi
    done
    progress_bar $PROCESSED_FILES $TOTAL_FILES "Qovluq strukturu işlənir..."
    eval tree -a -L "$TREE_DEPTH" . "$TREE_EXCLUDE_ARGS" -h -D -p -u -g -s --du --prune >> "$TEMP_CURRENT_CONTENT_FILE" 2>&1

    echo -e "\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"

    # 5. Last 60 Terminal Lines
    echo -e "\n## Last 60 Terminal Lines\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    echo -e "\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    history | tail -n 60 >> "$TEMP_CURRENT_CONTENT_FILE" 2>&1
    echo -e "\n\`\`\`\n" >> "$TEMP_CURRENT_CONTENT_FILE"
    
    # Compare with last ingest and determine version increment
    NEW_VERSION="$CURRENT_VERSION" # Default to current version if no significant change
    DIFF_SUMMARY=""
    DIFF_PERCENTAGE=0

    if [ -f "$LAST_INGEST_FILE" ]; then
        progress_bar $PROCESSED_FILES $TOTAL_FILES "Dəyişikliklər hesablanır..."
        DIFF_PERCENTAGE=$(calculate_overall_diff_percentage "$LAST_INGEST_FILE" "$TEMP_CURRENT_CONTENT_FILE")
        
        if (( DIFF_PERCENTAGE == 0 )); then
            NEW_VERSION="$CURRENT_VERSION"
            OUTPUT_FILE="$INGEST_DEBUG_DIR/${CURRENT_DIR_NAME}_${CURRENT_VERSION}.md"
            DIFF_SUMMARY="Məzmun dəyişikliyi yoxdur. Eyni versiya yeniləndi."
        else
            NEW_VERSION=$(get_semantic_version "$DIFF_PERCENTAGE" "$CURRENT_VERSION")
            DIFF_SUMMARY="Layihə məzmunu ${DIFF_PERCENTAGE}% dəyişdi."
        fi

        # Prepare changelog entry
        CHANGELOG_ENTRY="\n---"
        CHANGELOG_ENTRY+="\nVersiya: $NEW_VERSION ($(date '+%Y-%m-%d %H:%M:%S'))"
        CHANGELOG_ENTRY+="\n${DIFF_SUMMARY}\n"

        # Move previous ingest file to history if version is incremented
        if [[ "$NEW_VERSION" != "$CURRENT_VERSION" ]]; then
            mv "$LAST_INGEST_FILE" "$INGEST_HISTORY_DIR/"
            CHANGELOG_ENTRY+="\nƏvvəlki versiya ($CURRENT_VERSION) 'history' qovluğuna köçürüldü."
        fi

        # Append general diff overview to changelog
        diff_output_for_changelog=$(diff -u "$LAST_INGEST_FILE" "$TEMP_CURRENT_CONTENT_FILE" | grep -E '^\+\+\+|^---|^[\+\-][^+\-]*' | grep -v '^\+\+\+\|^---')

        if [[ -n "$diff_output_for_changelog" ]]; then
            if (( $(echo "$DIFF_PERCENTAGE > 50" | bc -l) )); then
                CHANGELOG_ENTRY+="\nLayihənin əsas komponentlərində böyük dəyişikliklər edildi. Detallar üçün tam fayllara baxın."
            else
                CHANGELOG_ENTRY+="\n\`\`\`diff\n"
                CHANGELOG_ENTRY+="$(echo "$diff_output_for_changelog" | head -n 100)\n"
                if (( $(echo "$diff_output_for_changelog" | wc -l) > 100 )); then
                    CHANGELOG_ENTRY+="... (Diff kəsildi - çox uzun)\n"
                fi
                CHANGELOG_ENTRY+="\`\`\`"
            fi
        else
            CHANGELOG_ENTRY+="\nMəzmun fərqliliyi aşkar edilmədi."
        fi

        echo -e "$CHANGELOG_ENTRY" >> "$CHANGELOG_FILE"
    else
        # First ingest, initialize changelog
        echo -e "---" > "$CHANGELOG_FILE"
        echo -e "İlk Ingest Versiyası: 0.0.1 ($(date '+%Y-%m-%d %H:%M:%S'))" >> "$CHANGELOG_FILE"
        echo -e "Layihənin ilkin vəziyyəti yaradıldı." >> "$CHANGELOG_FILE"
        echo -e "---" >> "$CHANGELOG_FILE"
        NEW_VERSION="0.0.1" # Initial version
    fi

    # Update the placeholder for version in the generated content
    sed -i "s/\[TO_BE_SET\]/$NEW_VERSION/" "$TEMP_CURRENT_CONTENT_FILE"

    # Final output file name with the new version
    OUTPUT_FILE="$INGEST_DEBUG_DIR/${CURRENT_DIR_NAME}_${NEW_VERSION}.md"

    # Move the temporary file to the final output location
    mv "$TEMP_CURRENT_CONTENT_FILE" "$OUTPUT_FILE"

    # --- SSH Transfer ---
    SSH_REMOTE_TARGET_DIR="${SSH_REMOTE_BASE_PATH}/${CURRENT_DIR_NAME}"
    SSH_REMOTE_FINAL_PATH="${SSH_REMOTE_TARGET_DIR}/${CURRENT_DIR_NAME}_${NEW_VERSION}.md"
    
    progress_bar $PROCESSED_FILES $TOTAL_FILES "SSH vasitəsilə köçürülür..."
    # Create remote directory if it doesn't exist
    ssh "$SSH_USER_HOST" "mkdir -p '$SSH_REMOTE_TARGET_DIR'" > /dev/null 2>&1
    
    # Copy the generated file
    scp -r "$OUTPUT_FILE" "$SSH_USER_HOST:$SSH_REMOTE_FINAL_PATH" > /dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        echo -ne "\n${GREEN}✅ SSH köçürməsi uğurla tamamlandı!${NC} Fayl uzaq ünvanda: ${YELLOW}$SSH_REMOTE_FINAL_PATH${NC}\n"
    else
        echo -ne "\n${RED}❌ SSH köçürməsi zamanı xəta baş verdi.${NC} Zəhmət olmasa SSH bağlantınızı və icazələri yoxlayın.\n"
    fi

    echo -ne "\n${GREEN}Ingest prosesi tamamlandı!${NC} Çıxış faylı: ${YELLOW}$OUTPUT_FILE${NC}, Dəyişikliklər qeydi: ${YELLOW}$CHANGELOG_FILE${NC}\n"
) &> /dev/null & # Redirect all output to /dev/null and run in background

echo -e "${GREEN}Ingest prosesi arxa fonda başladı! Terminalı tutmayacaq.${NC}"
echo -e "Proqresi izləmək üçün bir müddət gözləyin, tamamlandıqda terminalda mesaj görünəcək."
