const Groq = require('groq-sdk');
const fs = require('fs');

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// Read the current system info from the file
const systemInfoPath = '/data/data/com.termux/files/usr/etc/ai/src/.current_sys.info';
let currentSysInfo = '';
try {
    currentSysInfo = fs.readFileSync(systemInfoPath, 'utf-8').trim();
} catch (error) {
    console.error(`Error reading system info file: ${error.message}`);
    process.exit(1);
}

// Get the user message from command line arguments
const userMessage = process.argv.slice(2).join(' ');

async function main() {
    if (!userMessage) {
        console.error('Boş buraxma götəş!');
        process.exit(1);
    }

    try {
        const chatCompletion = await groq.chat.completions.create({
            model: 'meta-llama/llama-4-maverick-17b-128e-instruct',
            messages: [
                {
                    role: 'system',
                    content: `Siz çox bacarıqlı bir proqramçı və kiber təhlükəsizlik mütəxəssisisiniz, həmçinin Linux əməliyyat sistemləri və IT infrastrukturunda geniş biliklərə maliksiniz. Əsas məqsədiniz istifadəçilərə **Termux Android  41** sistemində dəqiq, icra oluna bilən, effektiv və təhlükəsiz həllər təqdim etməkdir. Cavablarınız qısa, dəqiq və dərhal tətbiq oluna bilən formada olmalıdır, hər hansı əlavə şərh və izah yalnız **şərh (comment)** olaraq təqdim edilməlidir.  \n\nƏgər əmr və ya skript təqdim edirsinizsə, bunlar birbaşa icra oluna biləcək şəkildə olmalı, heç bir dəyişən və ya müvəqqəti parametr tələb olunmamalıdır. Bütün cavablar **Bash**, **Python**, **JavaScript**, **PHP**, və ya **Batch** proqramlaşdırma dillərində olmalı və hər bir addım **şərhlərlə** izah edilməlidir. Əlavə məlumatlar yalnız istifadəçiyə lazım olan halda təqdim edilməlidir.  \n\nCavablarınız təhlükəsiz, effektiv və sistemin sabitliyini qoruyaraq riskləri minimuma endirən şəkildə olmalıdır. Əgər hər hansı risk və ya qeyri-müəyyənlik varsa, cavabda mütləq **şərh olaraq xəbərdarlıq** edilməlidir.  \n\n**Xüsusi Təhlükəsizlik Təlimatları:**  \n- Hər hansı əmrin və ya skriptin icrasından əvvəl istifadəçiləri mümkün təsirlər, təhlükəsizlik riskləri və zərər ehtimalları barədə **şərhlə xəbərdar edin**. Ən önəmlisi  isə qətiyyən cavabını bilmədiyin mövzuların cavabını bilirmiş kimi davranaraq, yalançı, qeyri-real bir fikir bildiməkdən mühtləq şəkildə qaçının. İstifadəçiyə yanlız və yanlız doğru istiqamət göstərin. Mümkün qədər qısa formatlarda cavablandırmağı üstün tutun. Əyləncəli, şən, professional və gijdillax balası kimi bir tonda sıx-sıx emojilərlə yazan və zarafatcıl söyüşlə danışmağı sevən qəhbə kimi enerjili xarakterə sahib ağıllı qəhibəm kimi nə istəsəm birbaşa əməl etmək vəzifəndir! \n\n**Sistem və qurğularım haqqında hazırki məlumatlar:**  \n------------------- \n\n ${currentSysInfo} \n\n---\n\n`
                },
                {
                    role: 'user',
                    content: `'please give me single line command from all these steps all as a single merged \n\nNOTE: The instruction has been outdated:\nFedora 19 ships with Ruby 2.0 and Metasploit requires 1.9.3 to function. rvm is required to get 1.9.3 running\nMetasploit directory structure has been changed. msf/ is now msf3/\nRuby-extension pcaprub is no longer distributed with Metasploit. Use gem install pcaprub\n🔗 Dependencies\nInstall the Ruby dependencies using yum or dnf:\n$ sudo dnf -y install ruby-irb rubygems rubygem-bigdecimal rubygem-rake rubygem-i18n rubygem-bundler\nInstall the git and the svn client:\n$ sudo dnf -y install git svn\nIn order to build the native extensions (pcaprub, lorcon2, etc), the following packages need to be installed:\n$ sudo dnf builddep -y ruby\nor with yum:\n$ sudo yum-builddep -y ruby\nthen:\n$ sudo dnf -y install ruby-devel libpcap-devel\nGet the latest version of rake\n$ sudo gem install rake\n🔗 Database support\nIn order to use the database functionality, RubyGems along with the appropriate drivers must be installed: Postgres is the recommended database:\n$ sudo dnf -y install postgresql-server postgresql-devel\n$ sudo gem install pg\nUnfortunately the ruby-postgres RPM can't be used as a replacement.\nOr for MySQL:\n$ sudo dnf -y install mysql-server ruby-mysql\nSqlite will work for basic tasks, but is no longer supported!\n$ sudo dnf -y install sqlite rubygem-sqlite3\n🔗 Metasploit Framework\nOnce the dependencies have been installed, download the Unix tarball from the Metasploit download page and run the following commands:\n$ wget http://downloads.metasploit.com/data/releases/framework-latest.tar.bz2\n$ tar -jxf framework-latest.tar.bz2\n$ sudo mkdir -p /opt/metasploit4\n$ sudo cp -a msf/ /opt/metasploit4/msf\n$ sudo chown root:root -R /opt/metasploit4/msf\n$ sudo ln -sf /opt/metasploit4/msf/msf* /usr/local/bin/\nOr checkout the source from the upstream git repository in a directory of your choice.\n$ git clone git://github.com/rapid7/metasploit-framework.git\n🔗 Metasploit Extensions\nThe Metasploit framework includes a few native Ruby extensions that must be compiled in order to use certain types of modules.\nTo enable WiFi modules:\n$ sudo bash\n# cd  /opt/metasploit4/msf/external/ruby-lorcon2/\n# svn co http://802.11ninja.net/svn/lorcon/trunk lorcon2\n# cd lorcon2\n# ./configure --prefix=/usr && make && make install\n# cd ..\n# ruby extconf.rb\n# make && make install\nTo enable raw socket modules:\n$ sudo gem install pcaprub\n🔗 Updates\nThe Metasploit Framework is updated daily with the latest exploits, payloads, features, and bug fixes. To update your installation of the framework:\n$ sudo svn update /opt/metasploit4/msf/\nThis can also be installed into the root user's crontab:\n$ sudo crontab -e -u root # enter the line below\n 1 * * * * /usr/bin/svn update  /opt/metasploit4/msf/ >> /var/log/msfupdate.log 2>&1\n🔗 Database Configuration\nNow that the framework is installed, you'll want to configure a database connection, and enable the framework to connect to it:\nFor postgres, see Metasploit Postgres Setup (recommended by upstream)\nFor mysql, see mysql_setup\nFor sqlite, see sqlite_setup (upstream: "not supported!!").'`
                },
                {
                    role: 'assistant',
                    content: `'sudo dnf -y install ruby-irb rubygems rubygem-bigdecimal rubygem-rake rubygem-i18n rubygem-bundler git svn ruby-devel libpcap-devel postgresql-server postgresql-devel rubygem-mysql2 sqlite rubygem-sqlite3 && sudo dnf builddep -y ruby && sudo gem install rake pg pcaprub && wget http://downloads.metasploit.com/data/releases/framework-latest.tar.bz2 && tar -jxf framework-latest.tar.bz2 && sudo mkdir -p /opt/metasploit4 && sudo cp -a msf/ /opt/metasploit4/msf && sudo chown root:root -R /opt/metasploit4/msf && sudo ln -sf /opt/metasploit4/msf/msf* /usr/local/bin/ && git clone git://github.com/rapid7/metasploit-framework.git && sudo bash -c 'cd /opt/metasploit4/msf/external/ruby-lorcon2/ && svn co http://802.11ninja.net/svn/lorcon/trunk lorcon2 && cd lorcon2 && ./configure --prefix=/usr && make && make install && cd .. && ruby extconf.rb && make && make install' && sudo svn update /opt/metasploit4/msf/ && (echo '1 * * * * /usr/bin/svn update /opt/metasploit4/msf/ >> /var/log/msfupdate.log 2>&1' | sudo crontab -u root)'`
                },
                {
                    role: 'user',
                    content: 'please give me single line command that will solve or help me based on explanation below, if single line command is not possible then ypu can give script to solving it, but most of time prefer to only giving single line commands that will do all steps at once with single execution, thanks. Now lets focus on the main thing below: \n' + userMessage
                }
            ],
            "temperature": 1,
            "max_tokens": 8000,
            "top_p": 0.6,
            "stream": true,
            "seed": 2353552,
            "stop": ['\n```\n\n','<\think>','###\n']
        });

        // Stream only the response message content, filtering out everything else
        for await (const chunk of chatCompletion) {
            const content = chunk.choices[0]?.delta?.content || '';
            if (content) {
                process.stdout.write(content);  // Only print the actual response message
            }
        }
    } catch (error) {
        console.error('Error occurred:', error);
    }
}


main();
