# test_api.sh
#!/bin/bash

# Bu skript WhatsCore.AI Botunun API endpoint-lərini avtomatik test etmək üçün istifadə olunur.
# Nəticələr 'api_test_results.log' faylına yazılacaq.
# Terminalda jq quraşdırılmış olmalıdır: sudo apt-get install jq (Debian/Ubuntu)

BASE_URL="http://localhost:9876/api"
LOG_FILE="../logs/api_test_results.log"
WHATSAPP_NUMBER="994702353552@c.us" # Test üçün istifadə olunan WhatsApp nömrəsi
CONTACT_ID="994554466980@c.us" # Test üçün bir nümunə kontakt ID-si
# Mesaj ID-si dinamikdir, əvvəlcədən bir mesajın ID-sini buraya daxil etməlisiniz.
# Məsələn, botdan gələn son mesajın ID-si ola bilər.
MESSAGE_ID="true_994702353552@c.us_3EB02071E09801EA598181" 
LOCAL_IMAGE_PATH="./test.jpeg" # Lokal test şəkili üçün yol (mövcud olmalıdır)

# Log faylını təmizlə
> "$LOG_FILE"

# Funksiya: Test nəticəsini loglamaq
log_test_result() {
    TEST_TITLE=$1
    REQUEST_METHOD=$2
    REQUEST_URL=$3
    REQUEST_BODY=$4
    RESPONSE_STATUS=$5
    RESPONSE_BODY=$6

    echo "====================================================" >> "$LOG_FILE"
    echo "TEST BAŞLIĞI: $TEST_TITLE" >> "$LOG_FILE"
    echo "ZAMAN: $(date)" >> "$LOG_FILE"
    echo "--- SORĞU ---" >> "$LOG_FILE"
    echo "Metod: $REQUEST_METHOD" >> "$LOG_FILE"
    echo "URL: $REQUEST_URL" >> "$LOG_FILE"
    if [ -n "$REQUEST_BODY" ]; then
        echo "Gövde: $REQUEST_BODY" >> "$LOG_FILE"
    fi
    echo "--- CAVAB ---" >> "$LOG_FILE"
    echo "Status: $RESPONSE_STATUS" >> "$LOG_FILE"
    echo "Gövde:" >> "$LOG_FILE"
    # JSON cavabı formatlamaq üçün jq istifadə edin, əgər yoxdursa sadəcə çap edin
    echo "$RESPONSE_BODY" | jq '.' 2>/dev/null || echo "$RESPONSE_BODY" >> "$LOG_FILE"
    echo "" >> "$LOG_FILE"
}

# Funksiya: cURL POST sorğusu göndərmək
send_curl_request() {
    TITLE=$1
    METHOD=$2
    ENDPOINT=$3
    DATA=$4
    HEADER="Content-Type: application/json"

    echo "--- Test edilir: $TITLE ($METHOD $ENDPOINT) ---"
    
    # curl -s -X METHOD -H HEADER -d DATA URL -w "%{http_code}"
    # -s: Silent mode, progress bar-ı göstərmə
    # -w "%{http_code}": HTTP status kodunu sona yaz
    RESPONSE=$(curl -s -X "$METHOD" -H "$HEADER" -d "$DATA" "$BASE_URL$ENDPOINT" -w "%{http_code}")
    
    HTTP_STATUS="${RESPONSE:(-3)}" # Cavabın son 3 simvolu status kodudur
    RESPONSE_BODY="${RESPONSE:0:(-3)}" # Cavabın qalanı gövdedir

    log_test_result "$TITLE" "$METHOD" "$BASE_URL$ENDPOINT" "$DATA" "$HTTP_STATUS" "$RESPONSE_BODY"
    echo "Tamamlandı. Nəticə log faylında: $LOG_FILE"
    echo ""
}

# Funksiya: cURL GET sorğusu göndərmək
send_curl_get_request() {
    TITLE=$1
    ENDPOINT=$2

    echo "--- Test edilir: $TITLE (GET $ENDPOINT) ---"
    
    RESPONSE=$(curl -s -X GET "$BASE_URL$ENDPOINT" -w "%{http_code}")
    
    HTTP_STATUS="${RESPONSE:(-3)}"
    RESPONSE_BODY="${RESPONSE:0:(-3)}"

    log_test_result "$TITLE" "GET" "$BASE_URL$ENDPOINT" "" "$HTTP_STATUS" "$RESPONSE_BODY"
    echo "Tamamlandı. Nəticə log faylında: $LOG_FILE"
    echo ""
}

# --- Testlərin icrası ---

echo "API Testləri Başlayır..." >> "$LOG_FILE"
echo "====================================================" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# 1. API Sağlamlıq və Status Yoxlamaları
send_curl_get_request "API Sağlamlıq Yoxlaması" "/health"
send_curl_get_request "WhatsApp Klient Statusu" "/status"
send_curl_get_request "Klientin Hazırki Vəziyyəti" "/get-state"

# 2. Mesaj Göndərmə Marşrutları
send_curl_request "Mətn Mesajı Göndərmə" "POST" "/send-text" "{\"number\": \"$WHATSAPP_NUMBER\", \"message\": \"Salam, bu avtomatlaşdırılmış test mesajıdır.\", \"quotedMsgId\": \"$MESSAGE_ID\"}" # quotedMsgId cavab (reply) üçün istifadə edilə bilər
send_curl_request "Media Mesajı Göndərmə (URL)" "POST" "/send-media" "{\"number\": \"$WHATSAPP_NUMBER\", \"filePath\": \"https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png\", \"caption\": \"Avtomatlaşdırılmış şəkil testi.\", \"quotedMsgId\": \"$MESSAGE_ID\"}"
# send_curl_request "Media Mesajı Göndərmə (Lokal Fayl)" "POST" "/send-media" "{\"number\": \"$WHATSAPP_NUMBER\", \"filePath\": \"$LOCAL_IMAGE_PATH\", \"caption\": \"Avtomatlaşdırılmış lokal şəkil testi.\", \"quotedMsgId\": \"$MESSAGE_ID\"}" # Lokal fayl nümunəsi (işə salmadan əvvəl yolu düzəldin)
send_curl_request "Məhsul Mesajı Göndərmə" "POST" "/send-product" "{\"number\": \"$WHATSAPP_NUMBER\", \"productId\": \"1001\", \"message\": \"Bu bir test məhsuludur.\", \"quotedMsgId\": \"$MESSAGE_ID\"}"
send_curl_request "Məkan Göndərmə" "POST" "/send-location" "{\"number\": \"$WHATSAPP_NUMBER\", \"latitude\": \"40.4035\", \"longitude\": \"49.8553\", \"description\": \"Test məkanı.\", \"quotedMsgId\": \"$MESSAGE_ID\"}"
send_curl_request "Kontakt Göndərmə" "POST" "/send-contact" "{\"number\": \"$WHATSAPP_NUMBER\", \"contactId\": \"$CONTACT_ID\", \"quotedMsgId\": \"$MESSAGE_ID\"}"

# 3. Söhbət (Chat) İdarəetmə Marşrutları
send_curl_get_request "Bütün Söhbətləri Almaq" "/get-chats"
send_curl_request "Söhbəti Arxivləmək" "POST" "/archive-chat" "{\"chatId\": \"$WHATSAPP_NUMBER\"}"
send_curl_request "Söhbəti Arxivdən Çıxarmaq" "POST" "/unarchive-chat" "{\"chatId\": \"$WHATSAPP_NUMBER\"}"
# Qeyd: Pin/Unpin mesajı üçün MESSAGE_ID-nin real, mövcud bir mesaj ID-si olduğundan əmin olun!
send_curl_request "Mesajı Pinləmək" "POST" "/pin-message" "{\"chatId\": \"$WHATSAPP_NUMBER\", \"messageId\": \"$MESSAGE_ID\"}"
send_curl_request "Mesajın Pinini Ləğv Etmək" "POST" "/unpin-message" "{\"chatId\": \"$WHATSAPP_NUMBER\", \"messageId\": \"$MESSAGE_ID\"}"
send_curl_request "Söhbəti Oxunmuş Kimi İşarələmək" "POST" "/mark-as-read" "{\"chatId\": \"$WHATSAPP_NUMBER\"}"
send_curl_request "Söhbəti Oxunmamış Kimi İşarələmək" "POST" "/mark-as-unread" "{\"chatId\": \"$WHATSAPP_NUMBER\"}"

# 4. Kontakt (Contact) İdarəetmə Marşrutları
send_curl_get_request "Kontaktın Profil Məlumatlarını Almaq" "/get-contact-info?number=$WHATSAPP_NUMBER"
send_curl_get_request "Kontaktın Profil Şəkli URL-ini Almaq" "/get-profile-pic?number=$WHATSAPP_NUMBER"
send_curl_get_request "Kontaktın Son Görülmə Statusunu Almaq" "/get-last-seen?number=$WHATSAPP_NUMBER"
send_curl_request "Kontakt Üçün Etiket Dəyişdirmək" "POST" "/edit-labels" "{\"contactId\": \"$WHATSAPP_NUMBER\", \"labelIds\": [\"1\", \"2\"]}" # Test üçün mövcud label ID-lərdən istifadə edin
send_curl_get_request "Bütün Kontaktları Almaq" "/get-all-contacts"

# 5. Servis İdarəetmə Marşrutları
send_curl_get_request "Xidmətləri Axtarmaq" "/search-services?q=təmir"

# 6. Klient İdarəetmə Funksiyaları
#send_curl_request "Sessiyanı Sıfırlamaq" "POST" "/reset-session" ""
#send_curl_request "WhatsApp Klientindən Çıxış" "POST" "/logout" ""

echo "====================================================" >> "$LOG_FILE"
echo "API Testləri Tamamlandı. Nəticələr: $LOG_FILE"
echo "====================================================" >> "$LOG_FILE"

