function test_notifications() {
  echo -e "\n[+] Notification testi..."
  python3 -c "from core.notification_manager import NotificationManager; nm = NotificationManager(); nm.add_notification('test', 'user123', 'Bu bir test bildirişidir')"
  read -p "[Enter] basaraq davam edin..."; main_menu
}

function test_rate_limits() {
  echo -e "\n[+] Rate limit testi..."
  python3 -c "from core.rate_limit_manager import RateLimitManager; rlm = RateLimitManager(); print(rlm.check_limit('groq_api', 1000))"
  read -p "[Enter] basaraq davam edin..."; main_menu
}

function test_backup() {
  echo -e "\n[+] Backup testi..."
  python3 -c "from core.backup_manager import BackupManager; bm = BackupManager(); print(bm.create_manual_backup())"
  read -p "[Enter] basaraq davam edin..."; main_menu
}

function test_performance() {
  echo -e "\n[+] Performance monitor testi..."
  python3 -c "from core.performance_monitor import PerformanceMonitor; pm = PerformanceMonitor(); print(pm.collect_metrics())"
  read -p "[Enter] basaraq davam edin..."; main_menu
}

# Əsas menyu yeniləməsi
function main_menu() {
  clear
  echo -e "${GREEN}== WHATScore.AI Test Paneli v2.0 ==${RESET}"
  echo "1) Flask AI Backend (bridge.py) testi"
  echo "2) Groq Media Analiz (groq_modules.py) testi"
  echo "3) Məhsul Axtarış (csv_search.py) testi"
  echo "4) WhatsApp Listener (wwjs_listener.js) testi"
  echo "5) Bütün Sistemi Başlat (run_wwjs.sh)"
  echo "6) Flask API Testləri"
  echo "7) Sistem Statusu"
  echo "8) Admin Panelini Başlat"
  echo "9) Günlük Hesabat Yarat"
  echo "10) Personalizasiya Testi"
  echo "11) Komanda Tanıma Testi"
  echo "12) Notification Testi"
  echo "13) Rate Limit Testi"
  echo "14) Backup Testi"
  echo "15) Performance Monitor Testi"
  echo "0) Çıxış"
  echo -n "Seçiminiz: "
  read choice
  case $choice in
    1) test_bridge;;
    2) test_groq_modules;;
    3) test_csv_search;;
    4) test_listener;;
    5) ./run_wwjs.sh;;
    6) test_api;;
    7) system_status;;
    8) start_admin_panel;;
    9) generate_report;;
    10) test_personalization;;
    11) test_command_recognition;;
    12) test_notifications;;
    13) test_rate_limits;;
    14) test_backup;;
    15) test_performance;;
    0) exit 0;;
    *) echo -e "${RED}Yanlış seçim!${RESET}"; sleep 1; main_menu;;
  esac
}
