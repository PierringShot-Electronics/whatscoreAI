/**
 * WhatsCore.AI - Maverick Edition
 *
 * WhatsApp Controller (Controller) - v4.5.0 (Təkmilləşdirilmiş)
 * Bu fayl WhatsApp klientinin funksionallığını idarə edir
 * və API marşrutlarından gələn sorğulara cavab verir.
 * YENİLİK: Əlavə mesaj göndərmə, söhbət və kontakt idarəetmə funksiyaları.
 */
const { MessageMedia, Location } = require('whatsapp-web.js');
const { logWithTimestamp } = require('../utils/logger');
const { products } = require('../services/productManager'); // [cite: uploaded:productManager.js]

// WhatsApp klient instansiyasını saxlamaq üçün (index.js tərəfindən ötürüləcək)
let whatsappClient;

// Klient instansiyasını təyin etmək üçün funksiya
function setWhatsAppClient(client) {
    whatsappClient = client;
    logWithTimestamp('✅ WhatsApp Klient instansiyası kontrollerə ötürüldü.');
}

// Klientin statusunu yoxlamaq
async function getClientStatus(req, res) {
    if (!whatsappClient) {
        logWithTimestamp('❌ WhatsApp Klient instansiyası mövcud deyil.');
        return res.status(503).json({ status: 'Error', message: 'WhatsApp Klient instansiyası hazır deyil.' });
    }
    try {
        const state = await whatsappClient.getState();
        logWithTimestamp(`ℹ️ WhatsApp Klient statusu sorğusu: ${state}`);
        res.status(200).json({ status: 'OK', clientState: state });
    } catch (error) {
        logWithTimestamp(`❌ Klient statusunu alarkən xəta:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Klient statusunu almaq mümkün olmadı.', error: error.message });
    }
}

// --- Mesaj Göndərmə Funksiyaları ---

// Sadə mətn mesajı göndərmək
async function sendText(req, res) {
    const { number, message } = req.body;
    if (!number || !message) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə və ya mesaj boş ola bilməz.' });
    }
    try {
        await whatsappClient.sendMessage(number, message);
        logWithTimestamp(`✉️ Mətn mesajı göndərildi: [${number}]`);
        res.status(200).json({ status: 'OK', message: 'Mətn mesajı uğurla göndərildi.' });
    } catch (error) {
        logWithTimestamp(`❌ Mətn mesajı göndərmə xətası [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Mesaj göndərmək mümkün olmadı.', error: error.message });
    }
}

// Media (şəkil, video, sənəd) göndərmək
async function sendMedia(req, res) {
    const { number, filePath, caption } = req.body; // filePath: lokal yol və ya URL
    if (!number || !filePath) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə və ya fayl yolu boş ola bilməz.' });
    }
    try {
        // Faylın lokal yoxsa URL olduğunu yoxla
        const media = await MessageMedia.fromUrl(filePath); // MessageMedia-nı import etməlisiniz
        media.data = media.data.replace(/^data:.+;base64,/, ''); // Base64 hissəsini təmizlə
        
        await whatsappClient.sendMessage(number, media, { caption: caption });
        logWithTimestamp(`📸 Media mesajı göndərildi: [${number}] - ${filePath}`);
        res.status(200).json({ status: 'OK', message: 'Media mesajı uğurla göndərildi.' });
    } catch (error) {
        logWithTimestamp(`❌ Media mesajı göndərmə xətası [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Media mesajı göndərmək mümkün olmadı.', error: error.message });
    }
}

// Kataloqdan məhsul göndərmək (WhatsApp Business üçün)
async function sendProduct(req, res) {
    const { number, productId, message } = req.body;
    if (!number || !productId) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə və ya məhsul ID-si boş ola bilməz.' });
    }
    try {
        // Məhsulu bazadan tap
        const product = products.find(p => p.id === productId); // [cite: uploaded:productManager.js]
        if (!product) {
            logWithTimestamp(`❌ Məhsul tapılmadı: ID ${productId}`);
            return res.status(404).json({ status: 'Error', message: `Məhsul ID ${productId} tapılmadı.` });
        }
        
        // WhatsApp API-si ilə məhsul göndərmək üçün xüsusi format tələb oluna bilər.
        // Bu hissə WhatsApp Business API-nin 'Product' mesaj tipi üçün spesifik implementasiya tələb edir.
        // Aşağıdakı nümunə ümumi bir mətn mesajı kimi göndərir, lakin rəsmi məhsul mesajı deyil.
        const productMessage = `Məhsul Məlumatı:\nAd: ${product.name}\nQiymət: ${product.price} AZN\nTəsvir: ${product.description}\n\n${message || ''}`;
        
        await whatsappClient.sendMessage(number, productMessage); // Və ya rəsmi Product mesajı API çağırışı
        logWithTimestamp(`📦 Məhsul mesajı göndərildi: [${number}] - ID ${productId}`);
        res.status(200).json({ status: 'OK', message: 'Məhsul mesajı uğurla göndərildi.' });
    } catch (error) {
        logWithTimestamp(`❌ Məhsul mesajı göndərmə xətası [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Məhsul mesajı göndərmək mümkün olmadı.', error: error.message });
    }
}

// Yeni: Məkan göndərmək
async function sendLocation(req, res) {
    const { number, latitude, longitude, description } = req.body;
    if (!number || !latitude || !longitude) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə, enlik və ya uzunluq boş ola bilməz.' });
    }
    try {
        const location = new Location(latitude, longitude, description); // Location-u import etməlisiniz
        await whatsappClient.sendMessage(number, location);
        logWithTimestamp(`📍 Məkan göndərildi: [${number}] - Lat: ${latitude}, Lon: ${longitude}`);
        res.status(200).json({ status: 'OK', message: 'Məkan uğurla göndərildi.' });
    } catch (error) {
        logWithTimestamp(`❌ Məkan göndərmə xətası [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Məkan göndərmək mümkün olmadı.', error: error.message });
    }
}

// Yeni: Kontakt göndərmək
async function sendContact(req, res) {
    const { number, contactId } = req.body; // contactId: göndəriləcək kontaktın id-si
    if (!number || !contactId) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə və ya kontakt ID-si boş ola bilməz.' });
    }
    try {
        const contact = await whatsappClient.getContactById(contactId); // Kontaktı əldə et
        if (!contact) {
            logWithTimestamp(`❌ Kontakt tapılmadı: ID ${contactId}`);
            return res.status(404).json({ status: 'Error', message: `Kontakt ID ${contactId} tapılmadı.` });
        }
        await whatsappClient.sendMessage(number, contact); // WhatsApp.js-də Kontakt obyektini birbaşa göndərmək
        logWithTimestamp(`👤 Kontakt göndərildi: [${number}] - ID ${contactId}`);
        res.status(200).json({ status: 'OK', message: 'Kontakt uğurla göndərildi.' });
    } catch (error) {
        logWithTimestamp(`❌ Kontakt göndərmə xətası [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Kontakt göndərmək mümkün olmadı.', error: error.message });
    }
}


// --- Söhbət (Chat) İdarəetmə Funksiyaları ---

// Bütün söhbətlərin siyahısını almaq
async function getChats(req, res) {
    try {
        const chats = await whatsappClient.getChats();
        logWithTimestamp(`💬 Bütün söhbətlər alındı: ${chats.length} söhbət`);
        res.status(200).json({ status: 'OK', data: chats.map(chat => ({
            id: chat.id._serialized,
            name: chat.name,
            isGroup: chat.isGroup,
            unreadCount: chat.unreadCount,
            lastMessage: chat.lastMessage ? chat.lastMessage.body : null
        }))});
    } catch (error) {
        logWithTimestamp(`❌ Söhbətləri alarkən xəta:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Söhbətləri almaq mümkün olmadı.', error: error.message });
    }
}

// Müəyyən bir söhbəti arxivləmək
async function archiveChat(req, res) {
    const { chatId } = req.body;
    if (!chatId) return res.status(400).json({ status: 'Error', message: 'Söhbət ID-si boş ola bilməz.' });
    try {
        const chat = await whatsappClient.getChatById(chatId);
        await chat.archive();
        logWithTimestamp(`🗄️ Söhbət arxivləndi: [${chatId}]`);
        res.status(200).json({ status: 'OK', message: `Söhbət ${chatId} uğurla arxivləndi.` });
    } catch (error) {
        logWithTimestamp(`❌ Söhbət arxivləmə xətası [${chatId}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Söhbəti arxivləmək mümkün olmadı.', error: error.message });
    }
}

// Müəyyən bir söhbəti arxivdən çıxarmaq
async function unarchiveChat(req, res) {
    const { chatId } = req.body;
    if (!chatId) return res.status(400).json({ status: 'Error', message: 'Söhbət ID-si boş ola bilməz.' });
    try {
        const chat = await whatsappClient.getChatById(chatId);
        await chat.unarchive();
        logWithTimestamp(`📂 Söhbət arxivdən çıxarıldı: [${chatId}]`);
        res.status(200).json({ status: 'OK', message: `Söhbət ${chatId} uğurla arxivdən çıxarıldı.` });
    } catch (error) {
        logWithTimestamp(`❌ Söhbət arxivdən çıxarma xətası [${chatId}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Söhbəti arxivdən çıxarmaq mümkün olmadı.', error: error.message });
    }
}

// Mesajı pinləmək
async function pinMessage(req, res) {
    const { chatId, messageId } = req.body;
    if (!chatId || !messageId) return res.status(400).json({ status: 'Error', message: 'Söhbət və ya Mesaj ID-si boş ola bilməz.' });
    try {
        const chat = await whatsappClient.getChatById(chatId);
        const message = await chat.getMessageById(messageId);
        await message.pin();
        logWithTimestamp(`📌 Mesaj pinləndi: [${messageId}] - [${chatId}]`);
        res.status(200).json({ status: 'OK', message: `Mesaj ${messageId} uğurla pinləndi.` });
    } catch (error) {
        logWithTimestamp(`❌ Mesaj pinləmə xətası [${messageId}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Mesajı pinləmək mümkün olmadı.', error: error.message });
    }
}

// Mesajın pinini ləğv etmək
async function unpinMessage(req, res) {
    const { chatId, messageId } = req.body;
    if (!chatId || !messageId) return res.status(400).json({ status: 'Error', message: 'Söhbət və ya Mesaj ID-si boş ola bilməz.' });
    try {
        const chat = await whatsappClient.getChatById(chatId);
        const message = await chat.getMessageById(messageId);
        await message.unpin();
        logWithTimestamp(`📍 Mesajın pini ləğv edildi: [${messageId}] - [${chatId}]`);
        res.status(200).json({ status: 'OK', message: `Mesaj ${messageId} pini uğurla ləğv edildi.` });
    } catch (error) {
        logWithTimestamp(`❌ Mesajın pinini ləğv etmə xətası [${messageId}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Mesajın pinini ləğv etmək mümkün olmadı.', error: error.message });
    }
}

// Yeni: Söhbəti oxunmuş kimi işarələmək
async function markChatAsRead(req, res) {
    const { chatId } = req.body;
    if (!chatId) return res.status(400).json({ status: 'Error', message: 'Söhbət ID-si boş ola bilməz.' });
    try {
        const chat = await whatsappClient.getChatById(chatId);
        await chat.sendSeen(); // sendSeen metodu oxunmuş kimi işarələyir
        logWithTimestamp(`✅ Söhbət oxunmuş kimi işarələndi: [${chatId}]`);
        res.status(200).json({ status: 'OK', message: `Söhbət ${chatId} oxunmuş kimi işarələndi.` });
    } catch (error) {
        logWithTimestamp(`❌ Söhbəti oxunmuş kimi işarələmə xətası [${chatId}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Söhbəti oxunmuş kimi işarələmək mümkün olmadı.', error: error.message });
    }
}

// Yeni: Söhbəti oxunmamış kimi işarələmək
async function markChatAsUnread(req, res) {
    const { chatId } = req.body;
    if (!chatId) return res.status(400).json({ status: 'Error', message: 'Söhbət ID-si boş ola bilməz.' });
    try {
        const chat = await whatsappClient.getChatById(chatId);
        await chat.markUnread(); // markUnread metodu oxunmamış kimi işarələyir
        logWithTimestamp(`✉️ Söhbət oxunmamış kimi işarələndi: [${chatId}]`);
        res.status(200).json({ status: 'OK', message: `Söhbət ${chatId} oxunmamış kimi işarələndi.` });
    } catch (error) {
        logWithTimestamp(`❌ Söhbəti oxunmamış kimi işarələmə xətası [${chatId}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Söhbəti oxunmamış kimi işarələmək mümkün olmadı.', error: error.message });
    }
}


// --- Kontakt (Contact) İdarəetmə Funksiyaları ---

// Kontaktın profil məlumatlarını almaq
async function getContactInfo(req, res) {
    const { number } = req.query;
    if (!number) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə boş ola bilməz.' });
    }
    try {
        const contact = await whatsappClient.getContactById(number);
        logWithTimestamp(`ℹ️ Kontakt məlumatı alındı: [${number}]`);
        res.status(200).json({ status: 'OK', data: {
            id: contact.id._serialized,
            name: contact.name || contact.pushname,
            isBlocked: contact.isBlocked,
            isBusiness: contact.isBusiness,
            isUser: contact.isUser,
            // Daha çox məlumat əlavə edilə bilər
        }});
    } catch (error) {
        logWithTimestamp(`❌ Kontakt məlumatını alarkən xəta [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Kontakt məlumatını almaq mümkün olmadı.', error: error.message });
    }
}

// Kontaktın profil şəklini (URL olaraq) almaq
async function getProfilePicUrl(req, res) {
    const { number } = req.query;
    if (!number) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə boş ola bilməz.' });
    }
    try {
        const url = await whatsappClient.getProfilePicUrl(number);
        logWithTimestamp(`🖼️ Profil şəkli URL-i alındı: [${number}]`);
        res.status(200).json({ status: 'OK', data: { profilePicUrl: url } });
    } catch (error) {
        logWithTimestamp(`❌ Profil şəkli URL-i alarkən xəta [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Profil şəkli URL-i almaq mümkün olmadı.', error: error.message });
    }
}

// Kontaktın son görülmə (last seen) statusunu almaq
async function getLastSeen(req, res) {
    const { number } = req.query;
    if (!number) {
        return res.status(400).json({ status: 'Error', message: 'Nömrə boş ola bilməz.' });
    }
    try {
        // whatsapp-web.js API-sində birbaşa last seen metodu yoxdur, 
        // lakin mövcud deyil, bəzi əlavə funksionallıqlar tələb edə bilər.
        // Bu funksiya yalnız əlaqənin mövcudluğunu yoxlayır.
        const contact = await whatsappClient.getContactById(number);
        logWithTimestamp(`👁️ Son görülmə statusu alındı: [${number}]`);
        res.status(200).json({ status: 'OK', data: { isAvailable: contact.isOnline } }); // isOnline last seen-i tam əvəz etmir
    } catch (error) {
        logWithTimestamp(`❌ Son görülmə statusunu alarkən xəta [${number}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Son görülmə statusunu almaq mümkün olmadı.', error: error.message });
    }
}

// Kontakt üçün etiket (label) əlavə etmək/dəyişmək
async function editLabels(req, res) {
    const { contactId, labelIds } = req.body; // labelIds: etiket ID-lərinin massivi
    if (!contactId || !labelIds || !Array.isArray(labelIds)) {
        return res.status(400).json({ status: 'Error', message: 'Kontakt ID-si və ya etiket ID-ləri boş ola bilməz.' });
    }
    try {
        const contact = await whatsappClient.getContactById(contactId);
        await contact.setLabels(labelIds);
        logWithTimestamp(`🏷️ Etiketlər dəyişdirildi: [${contactId}] - Etiketlər: ${labelIds.join(', ')}`);
        res.status(200).json({ status: 'OK', message: `Kontakt ${contactId} üçün etiketlər uğurla dəyişdirildi.` });
    } catch (error) {
        logWithTimestamp(`❌ Etiketləri dəyişdirərkən xəta [${contactId}]:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Etiketləri dəyişdirmək mümkün olmadı.', error: error.message });
    }
}

// Yeni: Bütün kontaktları almaq
async function getAllContacts(req, res) {
    try {
        const contacts = await whatsappClient.getContacts();
        logWithTimestamp(`👥 Bütün kontaktlar alındı: ${contacts.length} kontakt`);
        res.status(200).json({ status: 'OK', data: contacts.map(contact => ({
            id: contact.id._serialized,
            name: contact.name || contact.pushname || contact.id._serialized,
            isBusiness: contact.isBusiness,
            isUser: contact.isUser,
        }))});
    } catch (error) {
        logWithTimestamp(`❌ Bütün kontaktları alarkən xəta:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Bütün kontaktları almaq mümkün olmadı.', error: error.message });
    }
}

// --- Digər WhatsApp Funksiyaları ---

// Yeni: Klientin hazırki vəziyyətini almaq
async function getClientState(req, res) {
    if (!whatsappClient) {
        return res.status(503).json({ status: 'Error', message: 'WhatsApp Klient instansiyası hazır deyil.' });
    }
    try {
        const state = await whatsappClient.getState();
        logWithTimestamp(`ℹ️ Klientin hazırki vəziyyəti: ${state}`);
        res.status(200).json({ status: 'OK', clientState: state });
    } catch (error) {
        logWithTimestamp(`❌ Klientin vəziyyətini alarkən xəta:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Klientin vəziyyətini almaq mümkün olmadı.', error: error.message });
    }
}

// Yeni: Sessiyanı sıfırlamaq (yenidən başlamaq)
async function resetClientSession(req, res) {
    if (!whatsappClient) {
        return res.status(503).json({ status: 'Error', message: 'WhatsApp Klient instansiyası hazır deyil.' });
    }
    try {
        await whatsappClient.destroy(); // Mövcud sessiyanı bağla
        logWithTimestamp('🔄 WhatsApp Klient sessiyası sıfırlandı.');
        // Yenidən başlatmaq üçün initializeWhatsAppClient funksiyasını çağırmaq lazımdır
        // Bu, ya əl ilə, ya da index.js-dən avtomatik olaraq idarə olunmalıdır.
        // Hələlik sadece destroy edib cavab qaytarırıq.
        res.status(200).json({ status: 'OK', message: 'WhatsApp Klient sessiyası uğurla sıfırlandı. Yenidən başlatmaq üçün əl ilə müdaxilə tələb oluna bilər.' });
    } catch (error) {
        logWithTimestamp(`❌ Sessiyanı sıfırlayarkən xəta:`, error.message);
        res.status(500).json({ status: 'Error', message: 'Sessiyanı sıfırlamaq mümkün olmadı.', error: error.message });
    }
}

// Yeni: WhatsApp klientindən çıxış
async function logoutClient(req, res) {
    if (!whatsappClient) {
        return res.status(503).json({ status: 'Error', message: 'WhatsApp Klient instansiyası hazır deyil.' });
    }
    try {
        await whatsappClient.logout();
        logWithTimestamp('🚪 WhatsApp Klientindən uğurla çıxış edildi.');
        res.status(200).json({ status: 'OK', message: 'WhatsApp Klientindən uğurla çıxış edildi.' });
    } catch (error) {
        logWithTimestamp(`❌ Çıxış edərkən xəta:`, error.message);
        res.status(500).json({ status: 'Error', message: 'WhatsApp klientindən çıxış etmək mümkün olmadı.', error: error.message });
    }
}


module.exports = {
    setWhatsAppClient,
    getClientStatus,
    sendText,
    sendMedia,
    sendProduct,
    sendLocation, // export edildi
    sendContact,  // export edildi
    getChats,
    archiveChat,
    unarchiveChat,
    pinMessage,
    unpinMessage,
    markChatAsRead,   // export edildi
    markChatAsUnread, // export edildi
    getContactInfo,
    getProfilePicUrl,
    getLastSeen,
    editLabels,
    getAllContacts,   // export edildi
    getClientState,   // export edildi
    resetClientSession, // export edildi
    logoutClient      // export edildi
};

