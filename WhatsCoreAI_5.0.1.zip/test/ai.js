/**
 * WhatsCore.AI - Maverick Edition
 *
 * Süni İntellekt Servisi - v4.7 (Vision + Chat + Audio Tam Təkmilləşdirilmiş)
 * YENİLİK: Şəkil/Video, Səsli mesaj və Məhsul sorğularının daha dəqiq emalı.
 * Whisper modeli üçün audition prompt dəstəyi. Video səs və görüntünün birgə analizi.
 */
const fs = require("fs-extra");
const path = require("path");
const Groq = require("groq-sdk");
const { getSystemPrompt } = require("../prompts/assistant_prompt");
const { getHistory, saveHistory } = require("./historyManager");
const { searchProducts } = require("./productManager");
const { createOrder } = require("./orderManager");
const { logWithTimestamp } = require("../utils/logger");

// --- API Açar Dəyişdirmə (Rolling) Məntiqi ---
if (!process.env.GROQ_API_KEYS)
  throw new Error("GROQ_API_KEYS .env faylında təyin edilməyib!");
const apiKeys = process.env.GROQ_API_KEYS.split(",")
  .map((key) => key.trim())
  .filter((key) => key);
if (apiKeys.length === 0) throw new Error("GROQ_API_KEYS siyahısı boşdur!");
let currentKeyIndex = 0;

function getGroqClient() {
  const apiKey = apiKeys[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length;
  logWithTimestamp(`🔄 Groq API açarı istifadə olunur: ...${apiKey.slice(-4)}`);
  return new Groq({ apiKey });
}

// Modelləri .env-dən oxu (Groq-un dəstəklədiyi modellərə uyğunlaşdırıldı)
const chatModel = process.env.GROQ_CHAT_MODEL || "llama3-8b-8192";
const visionModel = process.env.GROQ_VISION_MODEL || "llama3-8b-8192"; // Multimodal üçün də chat modeli
const transcriptionModel =
  process.env.GROQ_TRANSCRIPTION_MODEL || "whisper-large-v3";

// Audition promptunu oxumaq üçün
let auditionPromptContent = "";
const AUDITION_PROMPT_PATH = path.join(
  __dirname,
  "..",
  "prompts",
  "audition_prompt.md",
);
try {
  if (fs.existsSync(AUDITION_PROMPT_PATH)) {
    auditionPromptContent = fs.readFileSync(AUDITION_PROMPT_PATH, "utf8");
    logWithTimestamp(`✅ Audition prompt uğurla yükləndi.`);
  } else {
    logWithTimestamp(
      `⚠️ Audition prompt faylı tapılmadı: ${AUDITION_PROMPT_PATH}`,
    );
  }
} catch (error) {
  logWithTimestamp(`❌ Audition promptu oxunarkən xəta:`, error.message);
}

/**
 * Şəkil/Video kadrlarını analiz edir.
 * @param {string[]} imagePaths - Şəkil fayllarının yollarının massivi.
 * @param {string} audioTranscription - Video ilə birlikdə olan səs transkripsiyası (əgər varsa).
 * @returns {Promise<string>} Görüntülərin təsviri.
 */
async function analyzeImages(imagePaths, audioTranscription = "") {
  if (!visionModel) {
    logWithTimestamp(
      "⚠️ GROQ_VISION_MODEL .env-də təyin edilməyib, şəkil analizi ləğv edildi.",
    );
    return "Şəkil analizi üçün model konfiqurasiya edilməyib.";
  }
  if (!imagePaths || imagePaths.length === 0) return "";

  try {
    const groq = getGroqClient();
    const messagesContent = [];

    let promptText =
      "Zəhmət olmasa, bu görüntüləri detallı təsvir edin. Əgər texniki problem, cihaz, məhsul və ya başqa əhəmiyyətli obyekt göstərilibsə, onu müəyyən edin. Bütün kadrları birlikdə analiz edərək ümumi bir məna və kontekst çıxarın. Bu kəsiklər bir videonun kadrları da ola bilər.";

    if (audioTranscription) {
      promptText += `\n\nVideo ilə birlikdə əldə olunan səs transkripsiyası: "${audioTranscription}". Zəhmət olmasa, bu səsli məlumatı vizual məlumatla birləşdirərək tam bir analiz təqdim edin.`; // Səs və görüntü birgə analizi üçün prompt təkmilləşdirildi
    }

    messagesContent.push({
      type: "text",
      text: promptText,
    });

    for (const imagePath of imagePaths) {
      const image_data = await fs.readFile(imagePath, { encoding: "base64" });
      messagesContent.push({
        type: "image_url",
        image_url: { url: `data:image/jpeg;base64,${image_data}` },
      });
    }

    logWithTimestamp(
      `🖼️ Şəkil/kadr analizi başladı: ${imagePaths.length} kadr`,
    );
    const response = await groq.chat.completions.create({
      model: visionModel,
      messages: [
        {
          role: "user",
          content: messagesContent,
        },
      ],
    });
    const description = response.choices[0].message.content;
    logWithTimestamp(
      `✅ Şəkil/kadr analizi uğurlu: "${description.slice(0, 100)}..."`,
    );
    return description;
  } catch (error) {
    logWithTimestamp(`❌ Şəkil/kadr analizi xətası:`, error.message);
    return "Şəkilləri/kadrları analiz edərkən bir problem yarandı. Zəhmət olmasa, AI konfiqurasiyasını və ya API açarlarını yoxlayın.";
  }
}

/**
 * Səs faylını transkripsiya edir.
 * @param {string} filePath - Səs faylının yolu.
 * @returns {Promise<string>} Transkripsiya olunmuş mətn.
 */
async function transcribeAudio(filePath) {
  try {
    const groq = getGroqClient();
    logWithTimestamp(`🎤 Səs transkripsiyası başladı: ${filePath}`);
    const transcriptionOptions = {
      file: fs.createReadStream(filePath),
      model: transcriptionModel,
      language: "az", // Azərbaycan dili üçün
      temperature: 0.02,
    };

    // Audition promptunu Whisper modelinə göndəririk
    if (auditionPromptContent) {
      transcriptionOptions.prompt = auditionPromptContent;
      logWithTimestamp(`ℹ️ Whisper modelinə audition promptu göndərildi.`);
    }
    // Qeyd: Groq API-də Whisper modelində adətən "temperature" parametri dəstəklənmir.

    const transcription =
      await groq.audio.transcriptions.create(transcriptionOptions);
    logWithTimestamp(`✅ Səs transkripsiyası uğurlu: "${transcription.text}"`);
    return transcription.text;
  } catch (error) {
    logWithTimestamp(`❌ Audio transkripsiya xətası:`, error.message);
    return "Səsli mesajı transkripsiya edərkən bir problem yarandı. API açarlarınızı və ya model adını yoxlayın.";
  }
}

/**
 * Verilmiş sorğunun məhsul sorğusu olub olmadığını yoxlayır.
 * @param {string} query - İstifadəçi sorğusu.
 * @returns {boolean} Məhsul sorğusudursa true, əks halda false.
 */
function isProductQuery(query) {
  const keywords = [
    "qiymət",
    "neçəyədir",
    "stok",
    "var",
    "model",
    "adapter",
    "ekran",
    "batareya",
    "noutbuk",
    "ssd",
    "ram",
    "almaq",
    "sifariş",
    "təmir",
    "məhsul",
    "kataloq",
    "satış",
    "satırsınız",
  ];
  return keywords.some((keyword) => query.toLowerCase().includes(keyword));
}

/**
 * AI modelindən cavab alır.
 * @param {string} chatId - Söhbət ID-si.
 * @param {object} userInput - İstifadəçi girişi (mətn və ya media).
 * @param {string} contextType - Mesajın kontekst tipi (chat, image, video, audio, product, location).
 * @returns {Promise<string>} AI-nin cavabı.
 */
async function getAIResponse(chatId, userInput, contextType) {
  try {
    let userQueryText = userInput.text || "";
    let mediaDescription = "";
    let audioTranscriptionResult = ""; // Səs transkripsiyası nəticəsini saxlamaq üçün

    const audioMedia = userInput.media.find((m) => m.type === "ptt" || "audio");
    const imageMediaPaths = userInput.media
      .filter((m) => m.type === "image")
      .map((m) => m.path);

    if (audioMedia) {
      audioTranscriptionResult = await transcribeAudio(audioMedia.path);
      mediaDescription += `[İstifadəçi səsli mesaj göndərdi. Mətnə çevrilmiş məzmunu: "${audioTranscriptionResult}"]\n`;
    }

    if (imageMediaPaths && imageMediaPaths.length > 0) {
      // Video kadrlarını analiz edərkən səs transkripsiyasını da Vision modelinə ötürürük
      const imageDesc = await analyzeImages(
        imageMediaPaths,
        audioTranscriptionResult,
      );
      mediaDescription += `[İstifadəçi şəkil/video kadrları göndərdi. Vizual analiz nəticəsi: "${imageDesc}"]\n`;
    }

    // Əgər contextType 'product' isə və userQueryText boşdursa, `message.productId` əsasında sorğu hazırlayaq
    if (contextType === "product" && !userQueryText && userInput.productId) {
      userQueryText = `Məhsul sorğusu: ID ${userInput.productId}.`;
      if (userInput.productDescription) {
        userQueryText += ` Təsvir: "${userInput.productDescription}".`;
      }
    } else if (contextType === "product_query" && userQueryText.trim() === "") {
      userQueryText = "Məhsul haqqında məlumat istəyirəm.";
    }

    userQueryText = mediaDescription + userQueryText; // Media təsvirini istifadəçi sualına əlavə edirik

    const history = await getHistory(chatId);
    const systemPrompt = getSystemPrompt();

    let knowledgeBaseContent = "";
    if (contextType === "product_query" || isProductQuery(userQueryText)) {
      const searchResults = searchProducts(userQueryText);
      if (searchResults.length > 0) {
        knowledgeBaseContent =
          "[BİLİK BAZASI NƏTİCƏLƏRİ]:\n" +
          searchResults
            .slice(0, 5)
            .map(
              (p) =>
                `- ID: ${p.id}, Ad: "${p.name}", Qiymət: ${p.price} AZN, Təsvir: ${p.description}`,
            )
            .join("\n");
      } else {
        knowledgeBaseContent =
          "[BİLİK BAZASI NƏTİCƏLƏRİ]: Verilənlər bazasında bu sorğuya uyğun məhsul tapılmadı. İstifadəçiyə heç bir məhsul tapılmadığını bildirin və alternativ məhsul və ya xidmətlər təklif edin, yaxud daha dəqiq axtarış tələb edin.";
      }
    }

    // Əgər userQueryText boşdursa və media description da yoxdursa, AI-yə boş mesaj verildiyini bildirin
    if (userQueryText.trim() === "" && mediaDescription.trim() === "") {
      userQueryText =
        "İstifadəçi boş mesaj göndərdi. Xahiş edirəm, ona necə kömək edə biləcəyinizi soruşun.";
    }

    const fullPrompt =
      (knowledgeBaseContent ? `${knowledgeBaseContent}\n\n` : "") +
      `[İSTİFADƏÇİ SUALI]:\n${userQueryText}`;

    // ==================== DÜZƏLİŞ BAŞLAYIR ====================

    // Adım 1: Söhbət tarixçəsini API-nin gözlədiyi formata çeviririk.
    const formattedHistory = history
      .map((msg) => ({
        role: msg.sender === "user" ? "user" : "assistant",
        content: msg.content || "", // Əgər content boşdursa, '' olaraq göndər
      }))
      .filter(Boolean); // Hər ehtimala qarşı massivdəki boş elementləri təmizləyirik

    // Adım 2: API üçün son mesajlar massivini düzgün formatlanmış tarixçə ilə yaradırıq.
    const messagesForAPI = [
      { role: "system", content: systemPrompt },
      ...formattedHistory,
      { role: "user", content: fullPrompt },
    ];

    // ===================== DÜZƏLİŞ BİTİR =====================

    const groq = getGroqClient();
    const chatCompletion = await groq.chat.completions.create({
      messages: messagesForAPI,
      model: chatModel,
    });
    let responseText = chatCompletion.choices[0]?.message?.content || "";

    try {
      const responseJson = JSON.parse(responseText);
      if (responseJson.action === "create_order") {
        logWithTimestamp(
          `📦 AI sifariş yaratmaq tələb etdi:`,
          responseJson.details,
        );
        const newOrder = await createOrder(responseJson.details);
        responseText = `✅ Sifarişiniz uğurla qəbul olundu!\nSifariş nömrəniz: *${newOrder.orderId}*.\nTezliklə sizinlə əlaqə saxlanılacaq.`;
      }
    } catch (e) {
      /* Cavab JSON deyil */
    }

    // updateHistory istifadəçi sualı + AI cavabı ilə yaranır. Lakin,
    // artıq saveHistory funksiyası tək-tək mesajları qeyd etdiyi üçün,
    // bu updateHistory-ni birbaşa saveHistory-ə ötürməyə ehtiyac yoxdur.
    // Hər mesaj ayrı-ayrılıqda (gələn və gedən) historyManager tərəfindən saxlanılır.

    logWithTimestamp(`🧠 Groq AI cavabı generasiya edildi [${chatId}]`);
    return responseText;
  } catch (error) {
    logWithTimestamp(`❌ Groq AI servis xətası [${chatId}]:`, error);
    return "🤖 Üzr istəyirəm, AI ilə əlaqədə bir problem yarandı. API açarlarınızı və model adını yoxlayın.";
  } finally {
    // Temporary files artıq messageController tərəfindən silinir.
  }
}

module.exports = { getAIResponse };
