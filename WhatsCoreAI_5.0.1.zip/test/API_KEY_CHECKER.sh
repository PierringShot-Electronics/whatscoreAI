grep -o 'gsk_[a-zA-Z0-9].*' keys | while read key; do
  curl -s -H "Authorization: Bearer $key" https://api.groq.com/openai/v1/models | grep error && echo "❌ $key" || echo "✅ $key"
done
