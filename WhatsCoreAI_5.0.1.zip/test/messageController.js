/**
 * WhatsCore.AI - Maverick Edition
 *
 * Mesaj Controller (Controller) - v4.9.0 (Multi-Media & Albom Emalı)
 * YENİLİK: WhatsApp albomlarını və ardıcıl göndərilən media fayllarını
 * bir paket kimi emal edən "Media Buferi" sistemi əlavə edildi.
 * 5-ə qədər media tək sorğuda, 6+ media isə hissə-hissə göndərilir.
 */
const { getAIResponse } = require("../services/ai");
const mediaProcessor = require("../services/mediaProcessor");
const { logWithTimestamp } = require("../utils/logger");
const fs = require("fs-extra");
const { saveHistory } = require("../services/historyManager");
const { findOrCreateLead } = require("../services/leadManager");

// Mətn və Media üçün ayrı-ayrı buferlər
const textBuffer = {};
const mediaBuffer = {};
const TEXT_BUFFER_TIMEOUT = (process.env.BUFFER_TIMEOUT_SECONDS || 8) * 1000;
const MEDIA_BUFFER_TIMEOUT = 3000; // 3 saniyə

// --- Köməkçi Funksiyalar ---

async function replyToMessage(client, chatId, responseText, originalMessage) {
    try {
        if (!responseText || responseText.trim() === "") return;
        const options = { quotedMessageId: originalMessage ? originalMessage.id._serialized : null };
        const sentMessage = await client.sendMessage(chatId, responseText.trim(), options);
        logWithTimestamp(`✅ Cavab (Reply) uğurla göndərildi: [${chatId}]`);
        await saveHistory(chatId, { type: "text", content: responseText.trim(), sender: "assistant", quotedMsgId: originalMessage ? originalMessage.id._serialized : null }, sentMessage.id._serialized);
    } catch (error) {
        logWithTimestamp(`❌ Cavab göndərmə xətası [${chatId}]:`, error.message);
    }
}

// --- Mətn Buferinin Boşaldılması ---
async function flushTextBuffer(client, chatId) {
    if (!textBuffer[chatId] || textBuffer[chatId].messages.length === 0) return;
    const { messages, originalMessages } = textBuffer[chatId];
    const lastMessage = originalMessages[originalMessages.length - 1];
    const combinedText = messages.join("\n");
    logWithTimestamp(`⏳ Mətn Buferi boşaldılır [${chatId}]: "${combinedText}"`);
    delete textBuffer[chatId];
    try {
        const minThinkingTime = 1500;
        const aiPromise = getAIResponse(chatId, { text: combinedText, media: [] }, "chat");
        const [aiResponse] = await Promise.all([aiPromise, new Promise(resolve => setTimeout(resolve, minThinkingTime))]);
        await replyToMessage(client, chatId, aiResponse, lastMessage);
    } catch (error) {
        logWithTimestamp(`❌ Mətn buferindən AI cavabı alma xətası:`, error);
        await replyToMessage(client, chatId, "🤖 Üzr istəyirəm, bir xəta baş verdi.", lastMessage);
    }
}

// --- YENİ: Media Buferinin Boşaldılması ---
async function flushMediaBuffer(client, chatId) {
    if (!mediaBuffer[chatId] || mediaBuffer[chatId].messages.length === 0) return;
    const { messages } = mediaBuffer[chatId];
    const lastMessage = messages[messages.length - 1]; // Cavab üçün son mesajı götürürük
    logWithTimestamp(`⏳ Media Buferi boşaldılır [${chatId}]: ${messages.length} media faylı tapıldı.`);
    delete mediaBuffer[chatId];

    const temporaryFiles = [];
    const chat = await lastMessage.getChat();

    try {
        chat.sendStateTyping();
        let combinedCaption = messages.map(msg => msg.body || "").filter(caption => caption.trim() !== "").join("\n");
        let mediaInputs = [];

        // Bütün mediaları endiririk
        for (const msg of messages) {
            const mediaPath = await mediaProcessor.saveMedia(msg);
            temporaryFiles.push(mediaPath);
            mediaInputs.push({ path: mediaPath, mimeType: msg.mimetype, type: msg.type === 'sticker' ? 'image' : msg.type });
        }

        logWithTimestamp(`🖼️ Media paketində ${mediaInputs.length} fayl və "${combinedCaption}" başlığı var.`);

        // Sənin dediyin kimi 5-lik qruplara bölürük
        const CHUNK_SIZE = 5;
        for (let i = 0; i < mediaInputs.length; i += CHUNK_SIZE) {
            const chunk = mediaInputs.slice(i, i + CHUNK_SIZE);
            const userInput = {
                text: i === 0 ? combinedCaption : `(Davamı) Paket ${Math.floor(i / CHUNK_SIZE) + 1}`,
                media: chunk
            };
            
            logWithTimestamp(`🧠 AI-yə ${chunk.length} media ilə sorğu göndərilir...`);
            const minThinkingTime = 2000;
            const aiPromise = getAIResponse(chatId, userInput, 'media_album');
            const [aiResponse] = await Promise.all([aiPromise, new Promise(resolve => setTimeout(resolve, minThinkingTime))]);
            
            // Hər paket üçün ayrıca cavab veririk
            await replyToMessage(client, chatId, aiResponse, lastMessage);
        }

    } catch (error) {
        logWithTimestamp(`❌ Media buferini emal edərkən xəta:`, error);
        await replyToMessage(client, chatId, "🤖 Media fayllarınızı emal edərkən bir problem yarandı.", lastMessage);
    } finally {
        chat.clearState();
        await Promise.all(temporaryFiles.map(fp => fs.unlink(fp).catch(e => logWithTimestamp(`❌ Müvəqqəti media faylı silinmədi: ${fp}`, e.message))));
    }
}


// --- ƏSAS MESAJ EMALI FUNKSİYASI ---
async function handleMessage(client, message) {
  const chatId = message.from;
  if (message.fromMe || message.isStatus) return;

  const chat = await message.getChat();
  await chat.sendSeen();
  
  const lead = await findOrCreateLead(chatId);
  logWithTimestamp(`📨 Mesaj [${lead.status}] statuslu lead üçün emal edilir: [${lead.lead_id}]`);

  await saveHistory(chatId, { type: message.type, content: message.body || "", sender: "user", quotedMsgId: message.hasQuotedMsg ? message.quotedMsg.id._serialized : null }, message.id._serialized);

  // --- YENİ ROUTING MƏNTİQİ ---

  // 1. Media Mesajları üçün Bufer
  if (message.hasMedia) {
    if (textBuffer[chatId]) await flushTextBuffer(client, chatId); // Əvvəlki mətn buferini təmizlə
    
    if (mediaBuffer[chatId]?.timer) clearTimeout(mediaBuffer[chatId].timer);
    if (!mediaBuffer[chatId]) {
      mediaBuffer[chatId] = { messages: [] };
    }
    mediaBuffer[chatId].messages.push(message);
    logWithTimestamp(`📥 Media buferə əlavə olundu: [${chatId}]. Hazırda ${mediaBuffer[chatId].messages.length} fayl var.`);
    
    mediaBuffer[chatId].timer = setTimeout(() => flushMediaBuffer(client, chatId), MEDIA_BUFFER_TIMEOUT);
    return;
  }

  // 2. Mətn Mesajları üçün Bufer
  if (message.type === "chat" && message.body.trim() !== "") {
    if (mediaBuffer[chatId]) await flushMediaBuffer(client, chatId); // Əvvəlki media buferini təmizlə
    
    chat.sendStateTyping();
    if (textBuffer[chatId]?.timer) clearTimeout(textBuffer[chatId].timer);
    if (!textBuffer[chatId]) {
      textBuffer[chatId] = { messages: [], originalMessages: [] };
    }
    textBuffer[chatId].messages.push(message.body);
    textBuffer[chatId].originalMessages.push(message);

    textBuffer[chatId].timer = setTimeout(() => flushTextBuffer(client, chatId).finally(() => chat.clearState()), TEXT_BUFFER_TIMEOUT);
    return;
  }

  // 3. Digər Mesaj Tipləri (Məkan, Məhsul və s. - bufersiz)
  if (mediaBuffer[chatId]) await flushMediaBuffer(client, chatId);
  if (textBuffer[chatId]) await flushTextBuffer(client, chatId);

  // Bu hissə buferə düşməyən tək mesajlar üçündür (məs. location)
  try {
      chat.sendStateTyping();
      let userInput = { text: '', media: [] };
      let contextType = message.type;

      if (message.type === "location") {
        userInput.text = `İstifadəçi bir məkan göndərdi: Lat: ${message.location.latitude}, Lon: ${message.location.longitude}. Bu məkana ən yaxın servis mərkəzini tap.`;
      } else if (message.type === "product") {
        userInput.text = `İstifadəçi bir məhsul sorğusu göndərdi: ${message.body}`;
        contextType = "product_query";
      } else {
        // Gələcəkdə digər tiplər üçün məntiq
        return;
      }
      
      const aiResponse = await getAIResponse(chatId, userInput, contextType);
      await replyToMessage(client, chatId, aiResponse, message);

  } catch (error) {
      logWithTimestamp(`❌ Tək mesaj emalı xətası [${chatId}]:`, error);
  } finally {
      chat.clearState();
  }
}

module.exports = { handleMessage };

