#!/bin/bash

# === KONFİQURASİYA ===
DEFAULT_IP="http://localhost:9876"
DEFAULT_FROM="994702353552@c.us"
DEFAULT_API_KEY="api"

declare -A types=(
  ["1"]="text"
  ["2"]="image"
  ["3"]="audio"
  ["4"]="video"
  ["5"]="document"
  ["6"]="location"
  ["7"]="contact"
  ["8"]="product"
  ["9"]="buttons"
  ["10"]="chat"
)

echo "📦 Mövcud mesaj tipləri:"
for i in $(seq 1 10); do
  echo "$i. ${types[$i]}"
done

read -p "📩 Mesaj nömrəsini seçin: " sel
type="${types[$sel]}"
[[ -z "$type" ]] && echo "❌ Yanlış seçim!" && exit 1

read -p "📡 GET ya POST metodunu seçin (default: GET): " method
method="${method^^}"
[[ -z "$method" ]] && method="GET"

read -p "🌍 Server IP (default: $DEFAULT_IP): " ip
ip="${ip:-$DEFAULT_IP}"

read -p "🔑 API açarı (default: $DEFAULT_API_KEY): " api_key
api_key="${api_key:-$DEFAULT_API_KEY}"

read -p "👤 Göndərən nömrə (default: $DEFAULT_FROM): " from
from="${from:-$DEFAULT_FROM}"

# === Məzmun — Interactive Content ===
case "$type" in
  text)
    read -p "📝 Mesaj mətni: " msg
    content="{\"content\":\"$msg\"}"
    ;;
  image)
    read -p "📷 Şəkil yolu: " path
    read -p "🖊️ Caption: " caption
    content="{\"path\":\"$path\",\"caption\":\"$caption\"}"
    ;;
  audio)
    read -p "🎧 Audio fayl yolu: " path
    content="{\"path\":\"$path\"}"
    ;;
  video)
    read -p "🎥 Video yolu: " path
    read -p "🖊️ Caption: " caption
    content="{\"path\":\"$path\",\"caption\":\"$caption\"}"
    ;;
  document)
    read -p "📄 Fayl yolu: " path
    read -p "📎 Filename: " filename
    read -p "🖊️ Caption: " caption
    content="{\"path\":\"$path\",\"filename\":\"$filename\",\"caption\":\"$caption\"}"
    ;;
  location)
    read -p "📍 Latitude: " lat
    read -p "📍 Longitude: " lon
    read -p "🏢 Ad: " name
    read -p "🗺️ Ünvan: " address
    content="{\"latitude\":$lat,\"longitude\":$lon,\"name\":\"$name\",\"address\":\"$address\"}"
    ;;
  contact)
    read -p "👤 Ad: " name
    read -p "📞 Nömrə: " phone
    content="{\"name\":\"$name\",\"phone\":\"$phone\"}"
    ;;
  product)
    read -p "🛍 Məhsul adı: " name
    read -p "💸 Qiymət: " price
    content="{\"name\":\"$name\",\"price\":$price}"
    ;;
  buttons)
    read -p "📝 Əsas mətn: " text
    read -p "🔘 Butonlar (vergüllə): " buttons
    read -p "🏷️ Başlıq: " title
    read -p "📎 Alt yazı: " footer
    content="{\"text\":\"$text\",\"buttons\":[\"${buttons//,/\",\"}\"],\"title\":\"$title\",\"footer\":\"$footer\"}"
    ;;
  chat)
    read -p "💬 Sual: " msg
    content_encoded=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''$msg'''))")
    if [[ "$method" == "GET" ]]; then
      curl_cmd="curl -s -H \"X-API-KEY: $api_key\" \"$ip/api/process?type=chat&from=$from&content=$content_encoded\""
    else
      post_data="{\"type\":\"chat\",\"from\":\"$from\",\"content\":\"$msg\"}"
      curl_cmd="curl -s -X POST \"$ip/api/process\" -H \"Content-Type: application/json\" -H \"X-API-KEY: $api_key\" -d '$post_data'"
    fi
    echo -e "\n🔗 CURL əmri:\n$curl_cmd"
    echo -e "\n🧪 Server cavabı:"
    eval "$curl_cmd" | jq
    exit 0
    ;;
esac

# === Final request qurulması ===
if [[ "$method" == "GET" ]]; then
  encoded_content=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''$content'''))")
  curl_cmd="curl -s -H \"X-API-KEY: $api_key\" \"$ip/api/process?type=$type&from=$from&originalContent=$encoded_content\""
else
  post_data="{\"type\":\"$type\",\"from\":\"$from\",\"originalContent\":$content}"
  curl_cmd="curl -s -X POST \"$ip/api/process\" -H \"Content-Type: application/json\" -H \"X-API-KEY: $api_key\" -d '$post_data'"
fi

# === Nəticə
echo -e "\n🔗 CURL əmri:\n$curl_cmd"
echo -e "\n🧪 Server cavabı:"
eval "$curl_cmd" | jq