# === SSHD + NGROK AUTOSTART ===
if ! pgrep -x "sshd" > /dev/null; then
    sudo service ssh start
fi

if ! pgrep -f "ngrok tcp 22" > /dev/null; then
    nohup ngrok tcp 22 > ~/.ngrok.log 2>&1 &
    sleep 5
fi

NGROK_SSH=$(curl -s http://127.0.0.1:4040/api/tunnels | grep -oE 'tcp://[0-9a-zA-Z\.\:]*')
if [ ! -z "$NGROK_SSH" ]; then
    PORT=$(echo $NGROK_SSH | cut -d':' -f3)
    HOST=$(echo $NGROK_SSH | cut -d'/' -f3 | cut -d':' -f1)
    echo ""
    echo "╭─[🌐 Remote SSH Connection Ready]"
    echo "│"
    echo "│ ssh $USER@$HOST -p $PORT"
    echo "│"
    echo "╰────────────────────────────────"
fi
chsh -s $(which zsh)
