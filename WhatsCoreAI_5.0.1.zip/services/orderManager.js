/**
 * WhatsCore.AI - Maverick Edition
 *
 * Sifariş Meneceri (Order Manager) - v4.4.0
 * YENİLİK: Sifarişlərə avtomatik tarix və status əlavə edilməsi.
 */
const fs = require('fs-extra');
const path = require('path'); // DÜZƏLİŞ
const { v4: uuidv4 } = require('uuid');
const { logWithTimestamp } = require('../utils/logger');

const ORDERS_DB_PATH = path.join(__dirname, '..', 'data', 'orders.json');

// Sifariş faylının mövcudluğunu yoxlayır və lazım gələrsə yaradır
fs.ensureFileSync(ORDERS_DB_PATH);
if (fs.readFileSync(ORDERS_DB_PATH, 'utf-8').trim() === '') {
    fs.writeJsonSync(ORDERS_DB_PATH, [], { spaces: 2 });
}


/**
 * Yeni sifariş yaradır və verilənlər bazasına əlavə edir.
 * @param {object} orderDetails - AI tərəfindən göndərilən sifariş detalları.
 * @returns {Promise<object>} - Yaradılan yeni sifariş.
 */
async function createOrder(orderDetails) {
    try {
        const orders = await fs.readJson(ORDERS_DB_PATH, { throws: false }) || [];
        
        const newOrder = {
            orderId: uuidv4(),
            customerDetails: orderDetails.customer || {},
            productDetails: orderDetails.product || {},
            status: 'Qəbul edildi', // Avtomatik ilkin status
            createdAt: new Date().toISOString(), // Sifariş tarixi
            ...orderDetails // AI-dən gələn digər məlumatları da əlavə edirik
        };

        orders.push(newOrder);
        await fs.writeJson(ORDERS_DB_PATH, orders, { spaces: 4 });

        logWithTimestamp(`✅ Yeni sifariş yaradıldı: ${newOrder.orderId}`);
        return newOrder;
    } catch (error) {
        logWithTimestamp(`❌ Sifariş yaratmaq mümkün olmadı:`, error);
        throw new Error('Sifariş yaradılarkən daxili xəta baş verdi.');
    }
}

module.exports = { createOrder };
