/**
 * WhatsCore.AI - Maverick Edition
 *
 * Söhbət Tarixçəsi Meneceri (Lokal Fayl Sistemi ilə) - v4.5.2
 * YENİLİK: Söhbət tarixçəsini və mesajları lokal JSON fayllarında saxlayır.
 */
const fs = require('fs-extra'); // fs-extra istifadə edirik ki, qovluq yaratmaq asan olsun
const path = require('path');
const { logWithTimestamp } = require('../utils/logger');

// Çat tarixçələrinin saxlanılacağı qovluq
const CHAT_HISTORIES_DIR = path.join(__dirname, '..', 'data', 'chat_histories');

// Qovluğun mövcud olmasını təmin edirik
fs.ensureDirSync(CHAT_HISTORIES_DIR);
logWithTimestamp(`✅ Çat tarixçəsi qovluğu hazır: ${CHAT_HISTORIES_DIR}`);

/**
 * Verilmiş söhbət üçün lokal JSON faylından mesaj tarixçəsini oxuyur.
 * @param {string} chatId - Söhbət ID-si (məsələn, WhatsApp nömrəsi).
 * @returns {Promise<Array<Object>>} Söhbət mesajlarının massivi.
 */
async function getHistory(chatId) {
    const filePath = path.join(CHAT_HISTORIES_DIR, `${chatId}.json`);
    try {
        if (await fs.pathExists(filePath)) {
            const fileContent = await fs.readFile(filePath, 'utf8');
            const history = JSON.parse(fileContent);
            logWithTimestamp(`📜 Lokal fayldan tarixçə alındı [${chatId}]: ${history.length} mesaj.`);
            return history;
        } else {
            logWithTimestamp(`ℹ️ Lokal tarixçə faylı tapılmadı [${chatId}]. Yeni tarixçə yaradılır.`);
            return [];
        }
    } catch (error) {
        logWithTimestamp(`❌ Lokal tarixçə faylını oxuma xətası [${chatId}]:`, error.message);
        return [];
    }
}

/**
 * Yeni mesajı lokal JSON faylına əlavə edir.
 * Hər mesaj, mövcud tarixçəyə əlavə olunaraq fayla yenidən yazılır.
 * @param {string} chatId - Söhbət ID-si.
 * @param {Object} messageData - Saxlanılacaq mesaj məlumatları (type, content, sender, quotedMsgId, mediaInfo, vb.).
 * @param {string} messageId - Mesajın unikal ID-si (message.id._serialized).
 */
async function saveMessage(chatId, messageData, messageId) {
    const filePath = path.join(CHAT_HISTORIES_DIR, `${chatId}.json`);
    try {
        let history = await getHistory(chatId);
        
        // Eyni mesajı təkrar yaza bilmə ehtimalını azaltmaq üçün yoxlama
        const existingMessage = history.find(msg => msg.messageId === messageId);
        if (existingMessage) {
            logWithTimestamp(`⚠️ Mesaj artıq mövcuddur, təkrar saxlanılmır [${chatId}][${messageId}].`);
            return;
        }

        const newMessage = {
            ...messageData,
            messageId: messageId,
            timestamp: new Date().getTime() // Mesajın göndərilmə vaxtı
        };
        
        history.push(newMessage);
        await fs.writeFile(filePath, JSON.stringify(history, null, 2), 'utf8'); // Səliqəli format üçün null, 2
        logWithTimestamp(`💾 Lokal fayla mesaj saxlanıldı [${chatId}][${messageId}].`);
    } catch (error) {
        logWithTimestamp(`❌ Lokal fayla mesaj saxlama xətası [${chatId}][${messageId}]:`, error.message);
    }
}

// Modulun export etdiyi funksiyalar
module.exports = {
    getHistory,
    saveHistory: saveMessage // 'saveHistory' adı ilə 'saveMessage' funksiyasını təqdim edirik
};

