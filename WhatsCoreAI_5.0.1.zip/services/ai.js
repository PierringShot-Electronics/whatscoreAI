/**
 * WhatsCore.AI - Maverick Edition
 *
 * AI Service - v5.0.2 (Token & Stability Patch)
 * YENİLİK: Token limitini aşmamaq üçün tarixçə limiti daha da optimallaşdırıldı (MAX_MESSAGES = 10).
 * Bütün əvvəlki düzəlişlər qorunub saxlanılıb.
 */
const Groq = require("groq-sdk");
const fs = require("fs-extra");
const path = require("path");
const mime = require("mime-types");
const { getHistory } = require("./historyManager");
const { searchProducts } = require("./productManager");
const { searchServices } = require("./serviceManager");
const { logWithTimestamp } = require("../utils/logger");
const { getSystemPrompt } = require("../prompts/assistant_prompt");

const groqKeys = (process.env.GROQ_API_KEYS || "")
  .split(",")
  .map((k) => k.trim())
  .filter(Boolean);
if (groqKeys.length === 0)
  throw new Error("GROQ_API_KEYS .env faylında təyin edilməyib və ya boşdur!");
let currentGroqKeyIndex = 0;
let groq = new Groq({ apiKey: groqKeys[currentGroqKeyIndex] });

function rotateGroqKey() {
  currentGroqKeyIndex = (currentGroqKeyIndex + 1) % groqKeys.length;
  groq = new Groq({ apiKey: groqKeys[currentGroqKeyIndex] });
  logWithTimestamp(
    `🔄 Groq API açarı dəyişdirildi: ...${groqKeys[currentGroqKeyIndex].slice(-4)}`,
  );
}

const AUDITION_PROMPT_PATH = path.join(
  __dirname,
  "..",
  "prompts",
  "audition_prompt.md",
);
let auditionPromptContent = "";
try {
  if (fs.existsSync(AUDITION_PROMPT_PATH)) {
    auditionPromptContent = fs.readFileSync(AUDITION_PROMPT_PATH, "utf8");
    logWithTimestamp("✅ Audition prompt uğurla yükləndi.");
  }
} catch (error) {
  logWithTimestamp(`❌ Audition promptu oxunarkən xəta:`, error);
}

async function analyzeImage(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return "";
  logWithTimestamp(`🖼️ Şəkil/kadr analizi başladı: ${path.basename(filePath)}`);
  try {
    const imageAsBase64 = fs.readFileSync(filePath, "base64");
    const response = await groq.chat.completions.create({
      temperature: 0.22,
      model: "meta-llama/llama-4-scout-17b-16e-instruct",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Bu şəkili və ya video kadrını detallı analiz et. Üzərindəki hər hansı bir mətni, modeli, markanı, zədəni və ya qeyri-adi detalı qeyd et.",
            },
            {
              type: "image_url",
              image_url: { url: `data:image/jpeg;base64,${imageAsBase64}` },
            },
          ],
        },
      ],
    });
    return response.choices[0]?.message?.content || "";
  } catch (error) {
    logWithTimestamp(`❌ Şəkil analizi xətası:`, error.message);
    return "Şəkili analiz edərkən xəta baş verdi.";
  }
}

async function transcribeAudio(filePath) {
  const allowedMimeTypes = [
    "audio/mpeg",
    "audio/wav",
    "audio/ogg",
    "audio/opus",
    "audio/mp4",
    "audio/m4a",
    "audio/webm",
  ];
  const fileMimeType = mime.lookup(filePath);
  if (!filePath || !allowedMimeTypes.includes(fileMimeType)) return "";
  logWithTimestamp(
    `🎤 Səs transkripsiyası başladı: ${path.basename(filePath)}`,
  );
  try {
    const transcription = await groq.audio.transcriptions.create({
      file: fs.createReadStream(filePath),
      model: "whisper-large-v3-turbo",
      prompt: auditionPromptContent,
      language: "az",
      temperature: 0.02,
    });
    return transcription.text;
  } catch (error) {
    logWithTimestamp(`❌ Audio transkripsiya xətası:`, error.message);
    return "Səs faylını analiz edərkən xəta baş verdi.";
  }
}

async function getAIResponse(chatId, userInput) {
  for (let i = 0; i < groqKeys.length; i++) {
    try {
      let history = await getHistory(chatId);
      const MAX_MESSAGES = 10; // LİMİTİ DAHA DA AZALTDIQ!
      if (history.length > MAX_MESSAGES) {
        history = history.slice(-MAX_MESSAGES);
        logWithTimestamp(
          `⚠️ Token limitini aşmamaq üçün söhbət tarixçəsi ${MAX_MESSAGES} mesaja qısaldıldı.`,
        );
      }

      let mediaAnalysisResults = "";
      let transcriptionResults = "";
      if (userInput.media && userInput.media.length > 0) {
        const imagePromises = userInput.media
          .filter((m) => mime.lookup(m.path).startsWith("image/"))
          .map((m) => analyzeImage(m.path));
        const audioPromises = userInput.media
          .filter((m) => mime.lookup(m.path).startsWith("audio/"))
          .map((m) => transcribeAudio(m.path));
        mediaAnalysisResults = (await Promise.all(imagePromises))
          .filter(Boolean)
          .join("\n---\n");
        transcriptionResults = (await Promise.all(audioPromises))
          .filter(Boolean)
          .join(" ");
      }

      let combinedUserInput = userInput.text || "";
      if (transcriptionResults)
        combinedUserInput =
          `${combinedUserInput} [Səsli mesajdan transkripsiya: ${transcriptionResults}]`.trim();

      const productResults = searchProducts(combinedUserInput);
      const serviceResults = searchServices(combinedUserInput);
      let knowledgeBaseContent = "";
      if (productResults.length > 0 || serviceResults.length > 0) {
        knowledgeBaseContent = `[BİLİK BAZASI NƏTİCƏLƏRİ]:\n`;
        if (productResults.length > 0)
          knowledgeBaseContent += `TAPILAN MƏHSULLAR:\n${productResults.map((p) => `- ID: ${p.id}, Ad: ${p.name}, Qiymət: ${p.price} AZN`).join("\n")}\n`;
        if (serviceResults.length > 0)
          knowledgeBaseContent += `TAPILAN XİDMƏTLƏR:\n${serviceResults.map((s) => `- ID: ${s.id}, Ad: ${s.name}, Qiymət: ${s.price} AZN`).join("\n")}\n`;
      }

      const messages = [
        { role: "system", content: getSystemPrompt() },
        ...history.map((msg) => ({
          role: msg.sender === "user" ? "user" : "assistant",
          content: msg.content,
        })),
        {
          role: "user",
          content:
            `${knowledgeBaseContent}\n[MEDİA ANALİZİ NƏTİCƏLƏRİ]:\n${mediaAnalysisResults}\n\n[İSTİFADƏÇİ SORĞUSU]:\n${combinedUserInput}`.trim(),
        },
      ];

      const response = await groq.chat.completions.create({
        model: "meta-llama/llama-4-maverick-17b-128e-instruct",
        temperature: 0.27,
        messages,
      });
      return (
        response.choices[0]?.message?.content ||
        "Anlaşılmadı, zəhmət olmasa fərqli şəkildə ifadə edin."
      );
    } catch (error) {
      logWithTimestamp(
        `❌ Groq AI servis xətası [${chatId}]: ${error.message}`,
      );
      if (error.status === 429 || error.status === 413) {
        rotateGroqKey();
        logWithTimestamp(
          `Cəhd ${i + 1}/${groqKeys.length} uğursuz oldu. Növbəti açar yoxlanılır...`,
        );
      } else {
        return "🤖 Üzr istəyirəm, AI ilə əlaqədə naməlum bir problem yarandı.";
      }
    }
  }
  return "⚠️ Sistemdə müvəqqəti yüklənmə var. Bütün API açarları məşğuldur. Zəhmət olmasa, bir neçə dəqiqə sonra yenidən cəhd edin.";
}

module.exports = { getAIResponse };
