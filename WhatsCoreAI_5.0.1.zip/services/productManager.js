/**
 * WhatsCore.AI - Maverick Edition
 *
 * Məhsul Meneceri (Product Manager) - v4.4.1
 * DÜZƏLİŞ: `path` modulu düzgün import edildi.
 */
const fs = require('fs');
const path = require('path'); // DÜZƏLİŞ
const { parse } = require('csv-parse/sync');
const { logWithTimestamp } = require('../utils/logger');

const PRODUCTS_DB_PATH = path.join(__dirname, '..', 'data', 'products.csv');
let products = [];

try {
    if (fs.existsSync(PRODUCTS_DB_PATH)) {
        const fileContent = fs.readFileSync(PRODUCTS_DB_PATH);
        products = parse(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true,
            cast: (value, context) => {
                if (context.column === 'price' || context.column === 'stock') {
                    return parseFloat(value) || 0;
                }
                return value;
            }
        });
        logWithTimestamp(`✅ ${products.length} məhsul CSV verilənlər bazasından uğurla yükləndi.`);
    } else {
        logWithTimestamp(`⚠️ Məhsul verilənlər bazası tapılmadı: ${PRODUCTS_DB_PATH}`);
    }
} catch (error) {
    logWithTimestamp(`❌ Məhsul verilənlər bazasını oxumaq mümkün olmadı:`, error);
    products = [];
}

/**
 * Məhsulları açar sözlərə görə axtarır.
 * @param {string} query - Axtarış üçün istifadəçi sorğusu və ya məhsul ID-si.
 * @returns {Array} - Tapılan məhsulların massivi.
 */
function searchProducts(query) {
    if (!query) return [];

    const lowerCaseQuery = query.toLowerCase().trim();

    // İlk olaraq dəqiq ID ilə axtarış
    const byId = products.find(p => p.id && p.id.toLowerCase() === lowerCaseQuery);
    if (byId) return [byId];

    // Sonra ad və təsvirdə axtarış
    const searchTerms = lowerCaseQuery.split(/\s+/).filter(term => term.length > 2);
    if (searchTerms.length === 0) return [];

    return products.filter(product => {
        const productName = (product.name || '').toLowerCase();
        const productDescription = (product.description || '').toLowerCase();
        const productCategory = (product.category || '').toLowerCase();

        // Bütün axtarış sözləri məhsul məlumatlarında mövcud olmalıdır
        return searchTerms.every(term =>
            productName.includes(term) ||
            productDescription.includes(term) ||
            productCategory.includes(term)
        );
    });
}

module.exports = { searchProducts, products };
